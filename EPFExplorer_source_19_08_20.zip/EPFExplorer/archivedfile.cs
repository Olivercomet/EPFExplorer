﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DSDecmp;
using Ekona;

namespace EPFExplorer
{
    public class archivedfile
    {
        public uint hash;
        public uint offset;
        public uint size;
        public byte[] filebytes;
        public uint filemagic;
        public string filename = "";

        public arcfile parentarcfile;

        public void checkfilemagic()
        {
            if (filebytes.Length > 4 && filebytes != null)
                {
                if ((filebytes[1] != 0x00 || filebytes[2] != 0x00) && filebytes[3] == 0x00)
                    {
                    if (filebytes[0] == 0x10)
                        {
                        filebytes = DSDecmp.NewestProgram.Decompress(filebytes, new DSDecmp.Formats.Nitro.LZ10());
                        }
                    else if (filebytes[0] == 0x11)
                        {
                        filebytes = DSDecmp.NewestProgram.Decompress(filebytes, new DSDecmp.Formats.Nitro.LZ11());
                        }
                    }
                }


            if (filebytes == null)
                {
                Console.WriteLine("It seems DSDecmp may have messed up the decompression...");
                return;
                }

            filemagic = 99999999;   //unset



            //the following is all really shoddy, but as of right now, there isn't a good method of identifying the file types. The vast majority of files have no file magic.

            if (filebytes.Length > 8)
            {
                filemagic = BitConverter.ToUInt32(new byte[] { filebytes[6], filebytes[7], filebytes[8], filebytes[9] }, 0);

                if (filebytes[0] == 0x00 && filebytes[1] != 0x00 && filebytes[4] == 0x00) //tentatively, text
                    {
                    filemagic = 0x74786574;
                    if (!parentarcfile.uniquefilemagicsandfreq.ContainsKey(filemagic))
                        {
                        Console.WriteLine("creating file magic entry...");
                        parentarcfile.uniquefilemagicsandfreq.Add(filemagic, 1);
                        filebytes = ReadTextFile();
                        }
                    else
                        {
                        Console.WriteLine("do not need to create entry");
                        parentarcfile.uniquefilemagicsandfreq[filemagic] += 1;
                        filebytes = ReadTextFile();
                        }
                    }

                if (filebytes[1] != 0x00 && filebytes[2] != 0x00 && filebytes[2] != filebytes[1] && filebytes[3] == filebytes[1] && filebytes[4] != filebytes[1] && filebytes[5] == filebytes[1] && filebytes[6] != filebytes[1] && filebytes[7] == filebytes[1] && filebytes[8] != filebytes[1] && filebytes[9] == filebytes[1]) //tentatively, mpb
                {
                    filemagic = 0x4D504200;
                    if (!parentarcfile.uniquefilemagicsandfreq.ContainsKey(filemagic))
                    {
                        Console.WriteLine("creating file magic entry...");
                        parentarcfile.uniquefilemagicsandfreq.Add(filemagic, 1);
                    }
                    else
                    {
                        Console.WriteLine("do not need to create entry");
                        parentarcfile.uniquefilemagicsandfreq[filemagic] += 1;
                    }
                }

                if (filebytes.Length > 0x0F && filebytes[0] == 0x00 && filebytes[1] == 0x00 && filebytes[2] != 0x00 && filebytes[3] == 0x00 && filebytes[4] != 0x00 && filebytes[5] == 0x00 && filebytes[6] != 0x00 && filebytes[7] == 0x00 && filebytes[8] != 0x00 && filebytes[9] == 0x00 && filebytes[10] != 0x00 && filebytes[11] == 0x00 && filebytes[12] != 0x00 && filebytes[13] == 0x00 && filebytes[14] != 0x00 && filebytes[15] == 0x00) //tentatively, font
                {
                    filemagic = 0x544E4F46;
                    if (!parentarcfile.uniquefilemagicsandfreq.ContainsKey(filemagic))
                    {
                        Console.WriteLine("creating file magic entry...");
                        parentarcfile.uniquefilemagicsandfreq.Add(filemagic, 1);
                    }
                    else
                    {
                        Console.WriteLine("do not need to create entry");
                        parentarcfile.uniquefilemagicsandfreq[filemagic] += 1;
                    }
                }

                filemagic = BitConverter.ToUInt32(new byte[] { filebytes[1], filebytes[2], filebytes[3], filebytes[4] }, 0);

                switch (filemagic)
                {
                    case 0x5161754C:    //Luac file
                        if (!parentarcfile.uniquefilemagicsandfreq.ContainsKey(filemagic))
                        {
                            Console.WriteLine("creating file magic entry...");
                            parentarcfile.uniquefilemagicsandfreq.Add(filemagic, 1);
                        }
                        else
                        {
                            Console.WriteLine("do not need to create entry");
                            parentarcfile.uniquefilemagicsandfreq[filemagic] += 1;
                        }

                        //LUAs in normal arcs are LZ10 compressed, whereas arcs embedded in save files, they are LZ11 compressed.

                        if (filebytes[0] == 0x10)
                        {   
                            filebytes = DSDecmp.NewestProgram.Decompress(filebytes,new DSDecmp.Formats.Nitro.LZ10());
                        }
                        else if (filebytes[0] == 0x11)
                        {
                            filebytes = DSDecmp.NewestProgram.Decompress(filebytes, new DSDecmp.Formats.Nitro.LZ11());
                        }

                        break;
                }
            }

            if (filebytes.Length > 7)
            {
                if (!parentarcfile.uniquefilemagicsandfreq.ContainsKey(filemagic))//if it still hasn't been assigned
                {
                    filemagic = BitConverter.ToUInt16(new byte[] { filebytes[4], filebytes[5] }, 0);

                    switch (filemagic)
                    {
                        case 0xAF12:    //FMV
                            if (!parentarcfile.uniquefilemagicsandfreq.ContainsKey(filemagic))
                            {
                                Console.WriteLine("creating file magic entry...");
                                parentarcfile.uniquefilemagicsandfreq.Add(filemagic, 1);
                            }
                            else
                            {
                                Console.WriteLine("do not need to create entry");
                                parentarcfile.uniquefilemagicsandfreq[filemagic] += 1;
                            }
                            break;

                        default:
                            filemagic = 99999999;   //unset
                            break;
                    }
                }
            }
           
            if (filebytes.Length > 3)
            {
                if (!parentarcfile.uniquefilemagicsandfreq.ContainsKey(filemagic))//if it still hasn't been assigned
                {
                    filemagic = BitConverter.ToUInt16(new byte[] { filebytes[0], filebytes[1] }, 0);

                    switch (filemagic)
                    {
                        case 0x7C1F:    //maybesprite
                            if (!parentarcfile.uniquefilemagicsandfreq.ContainsKey(filemagic))
                            {
                                Console.WriteLine("creating file magic entry...");
                                parentarcfile.uniquefilemagicsandfreq.Add(filemagic, 1);
                                if (filebytes.Length > 0x240)
                                    {
                                   
                                     if (hash == 428985727)
                                     {
                                      filebytes = ConvertSpriteToRAW(filebytes);
                                         count_unique_colours(filebytes);
                                     }
                                }

                            }
                            else
                            {
                                Console.WriteLine("do not need to create entry");
                                parentarcfile.uniquefilemagicsandfreq[filemagic] += 1;
                                if (filebytes.Length > 0x240)
                                    {
                                   
                                    if (hash == 428985727)
                                        {
                                        filebytes = ConvertSpriteToRAW(filebytes);
                                       // count_unique_colours(filebytes);
                                        }
                                    
                                    }
                            }
                            break;
                        

                    }

                    if (!parentarcfile.uniquefilemagicsandfreq.ContainsKey(filemagic))//if it still hasn't been assigned

                    {
                        filemagic = BitConverter.ToUInt32(new byte[] { filebytes[0], filebytes[1], filebytes[2], filebytes[3] }, 0);

                        if (!parentarcfile.uniquefilemagicsandfreq.ContainsKey(filemagic))
                        {
                            Console.WriteLine("creating file magic entry...");
                            parentarcfile.uniquefilemagicsandfreq.Add(filemagic, 1);
                        }
                        else
                        {
                            Console.WriteLine("do not need to create entry");
                            parentarcfile.uniquefilemagicsandfreq[filemagic] += 1;
                        }
                    }

                    
                }

                
            }
        }




        public Bitmap TSBtoImage(Byte[] input)  //palettes aren't always the same length, this function is designed for the image in the downloadable newsletter
        {
            List<Byte> output = new List<Byte>();

            int offset = 0;

            //Turns out the 1F7C is part of the palette.

            Color[] palette = new Color[16];

            for (int i = 0; i < 16; i++)
                {
                palette[i] = parentarcfile.form1.ABGR1555_to_RGBA32(BitConverter.ToUInt16(input,offset));
                offset += 2;
                }

            offset = 0x20;

            int widthInPixels = 220;
            int heightInPixels = 94;

            Bitmap bm = new Bitmap(220,94);

            for (int y = 0; y < heightInPixels; y++)
            {
                for (int x = 0; x < widthInPixels; x++)
                {
                    //each nibble is one pixel

                    Color c = palette[input[offset] & 0x0F];

                    bm.SetPixel(x,y,c);
                    //output.Add((byte)c.R); //R
                    //output.Add((byte)c.G); //G
                    //output.Add((byte)c.B); //B
                    //output.Add((byte)(input[offset] >> 4)); //temp

                    x++;

                    c = palette[input[offset] >> 4];
                    
                    bm.SetPixel(x, y, c);

                    //output.Add((byte)c.R); //R
                    //output.Add((byte)c.G); //G
                    //output.Add((byte)c.B); //B

                    offset++;
                }
            }

            return bm;
            }









        public Byte[] ConvertSpriteToRAW(Byte[] input)
        {
            List<Byte> inputaslist = new List<Byte>(input.ToList());
            Byte[] temp = new Byte[inputaslist.Count - 0x240];


            Dictionary<int, List<Byte>> imagerowsandbytelists = new Dictionary<int, List<Byte>>();

            int numberofchunks = (inputaslist.Count - 0x240) / 64;

            //imagerowtowriteto will temporarily be set to stop after something reasonable, just until I look at the results more and figure out a way to know what it is ahead of time

            int width = 384;
            int currenthorizontalpixel = 0;

            int currentline = 0;

            List<int> keysinorder = new List<int>();

            for (int j = 0; j < numberofchunks; j++)     // for each chunk
                {
                for (int i = 0; i < 8; i++)   //for each line in each chunk
                    {
                    for (int byteinrow = 0; byteinrow < 8; byteinrow++)
                        {
                        temp[(currentline * width) + currenthorizontalpixel] = inputaslist[0x240 + (j * 64) + (i * 8) + byteinrow];  //offset of data -> correct chunk -> correct row -> correct byte in row
                        currenthorizontalpixel++;
                        }


                    if (currenthorizontalpixel > width)
                        {
                        currentline++;
                        currenthorizontalpixel = 0;
                        }
                }
                }


            return temp;
        }


        public Byte[] ReadTextFile() {

            List<Byte> filebytesaslist = new List<Byte>(filebytes.ToList());

            int count = BitConverter.ToInt32(filebytes,1);

            List<int> stringoffsets = new List<int>();

            List<List<Byte>> strings = new List<List<Byte>>();

            if (filebytes.Length > 5 + (count * 4) + count) //if it's shorter than this, it's unlikely to contain any actual text
            {
                for (int i = 0; i < count; i++)
                    {
                    stringoffsets.Add(BitConverter.ToInt32(filebytes, 5 + (i*4)));
                    }

                for (int i = 0; i < stringoffsets.Count; i++)
                    {
                    if (i == stringoffsets.Count - 1)   //if it's the last one, work out its length using the end of the file instead of the next one in the list (because there isn't a next one)
                    {
                        List<Byte> newstring = new List<Byte>(filebytes.ToList().GetRange(stringoffsets[i], filebytes.Length - stringoffsets[i]));

                        newstring.Add(0x0D);
                        newstring.Add(0x0A);

                        for (int index = 0; index < newstring.Count; index++)
                        {
                            if (newstring[index] == 0x00)
                            {
                                newstring.RemoveAt(index);
                            }
                        }
                        strings.Add(newstring);
                    }
                    else
                    {
                        List<Byte> newstring = new List<Byte>(filebytes.ToList().GetRange(stringoffsets[i], stringoffsets[i + 1] - stringoffsets[i])); //otherwise, get the length using the next one in the list

                        newstring.Add(0x0D);
                        newstring.Add(0x0A);
                    for (int index = 0; index < newstring.Count; index++)
                            {
                            if (newstring[index] == 0x00)
                                {
                                newstring.RemoveAt(index);
                                }
                            }
                        strings.Add(newstring);
                        
                    }
                    
                    
                    
                    }

                List<Byte> output = new List<Byte>();

                foreach (List<Byte> stringaslist in strings)
                    {
                    foreach (Byte b in stringaslist)
                        {
                        output.Add(b);
                        }
                    }

                return output.ToArray();
            }
            else
            {
                return filebytes;
            }


           
        }


        

        public void count_unique_colours(Byte[] filebytes)
            {
            List<Byte> uniquebytes = new List<byte>();

            List<Byte> filebyteswithoutheader = new List<Byte>(filebytes.ToList().GetRange(0x240,filebytes.Length - 0x240));

            foreach (Byte b in filebyteswithoutheader)
                {
                if (!uniquebytes.Contains(b))
                    {
                    uniquebytes.Add(b);
                    }
                }

            Console.WriteLine(uniquebytes.Count);
            Console.WriteLine("Min: " + uniquebytes.Min().ToString());
            Console.WriteLine("Max: " + uniquebytes.Max().ToString());

            for (int i = 0; i < 255; i++)
            {
                if (!uniquebytes.Contains(BitConverter.GetBytes(i)[0]))
                {
                    Console.WriteLine("The image doesn't contain byte " + i + "!");
                }
            }

            Console.WriteLine("breakpoint");
        
        
        
            }
    }


   
}
