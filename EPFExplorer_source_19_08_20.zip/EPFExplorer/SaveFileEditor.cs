﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EPFExplorer
{
    public partial class SaveFileEditor : Form
    {
        public SaveFileEditor()
        {
            InitializeComponent();
            inventoryBox.Items.Clear();
        }

        savefile activeSaveFile;

        public Form1 form1;
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.Title = "Select file";
            openFileDialog1.CheckFileExists = true;
            openFileDialog1.CheckPathExists = true;
            openFileDialog1.Filter = "DS Save (*.dsv)|*.dsv|DS Save (*.sav)|*.sav";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                activeSaveFile = new savefile();
                activeSaveFile.saveFileEditor = this;
                activeSaveFile.LoadFromFile(openFileDialog1.FileName);
                }
                
        }

        private void currentMissionChooser_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            activeSaveFile.SaveToFile();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void SaveFileEditor_Load(object sender, EventArgs e)
        {

        }

        private void penguinNameTextBox_TextChanged(object sender, EventArgs e)
        {
            if (penguinNameTextBox.TextLength > 0x0C)
                {
                penguinNameTextBox.Text = penguinNameTextBox.Text.Substring(0,0x0C);
                }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void containsDownloadable_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
