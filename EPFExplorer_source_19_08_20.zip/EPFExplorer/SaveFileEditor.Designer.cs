﻿namespace EPFExplorer
{
    partial class SaveFileEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.currentMissionChooser = new System.Windows.Forms.ComboBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.colourChooser = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.coinsChooser = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.penguinNameTextBox = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.inventoryUnlockable = new System.Windows.Forms.CheckBox();
            this.whistleUnlockable = new System.Windows.Forms.CheckBox();
            this.HQteleportUnlockable = new System.Windows.Forms.CheckBox();
            this.mapUnlockable = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.puffleKlutzy = new System.Windows.Forms.CheckBox();
            this.puffleChill = new System.Windows.Forms.CheckBox();
            this.puffleChirp = new System.Windows.Forms.CheckBox();
            this.puffleFlit = new System.Windows.Forms.CheckBox();
            this.pufflePop = new System.Windows.Forms.CheckBox();
            this.puffleLoop = new System.Windows.Forms.CheckBox();
            this.puffleFlare = new System.Windows.Forms.CheckBox();
            this.puffleBlast = new System.Windows.Forms.CheckBox();
            this.puffleBouncer = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.highScore6 = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.highScore5 = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.highScore4 = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.highScore3 = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.highScore2 = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.highScore1 = new System.Windows.Forms.NumericUpDown();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.inventoryBox = new System.Windows.Forms.CheckedListBox();
            this.containsDownloadable = new System.Windows.Forms.CheckBox();
            this.menuStrip1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.coinsChooser)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.highScore6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.highScore5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.highScore4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.highScore3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.highScore2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.highScore1)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(759, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(128, 26);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(128, 26);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(181, 141);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Current Mission";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // currentMissionChooser
            // 
            this.currentMissionChooser.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.currentMissionChooser.FormattingEnabled = true;
            this.currentMissionChooser.Location = new System.Drawing.Point(184, 161);
            this.currentMissionChooser.Name = "currentMissionChooser";
            this.currentMissionChooser.Size = new System.Drawing.Size(212, 24);
            this.currentMissionChooser.TabIndex = 1;
            this.currentMissionChooser.SelectedIndexChanged += new System.EventHandler(this.currentMissionChooser_SelectedIndexChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.containsDownloadable);
            this.groupBox2.Controls.Add(this.currentMissionChooser);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.colourChooser);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.coinsChooser);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.penguinNameTextBox);
            this.groupBox2.Location = new System.Drawing.Point(12, 42);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(412, 215);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "General settings";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Penguin colour";
            // 
            // colourChooser
            // 
            this.colourChooser.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.colourChooser.FormattingEnabled = true;
            this.colourChooser.Location = new System.Drawing.Point(10, 105);
            this.colourChooser.Name = "colourChooser";
            this.colourChooser.Size = new System.Drawing.Size(145, 24);
            this.colourChooser.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Coins";
            // 
            // coinsChooser
            // 
            this.coinsChooser.Location = new System.Drawing.Point(10, 161);
            this.coinsChooser.Maximum = new decimal(new int[] {
            -1,
            0,
            0,
            0});
            this.coinsChooser.Name = "coinsChooser";
            this.coinsChooser.Size = new System.Drawing.Size(145, 22);
            this.coinsChooser.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Penguin name";
            // 
            // penguinNameTextBox
            // 
            this.penguinNameTextBox.Location = new System.Drawing.Point(10, 49);
            this.penguinNameTextBox.Name = "penguinNameTextBox";
            this.penguinNameTextBox.Size = new System.Drawing.Size(145, 22);
            this.penguinNameTextBox.TabIndex = 0;
            this.penguinNameTextBox.TextChanged += new System.EventHandler(this.penguinNameTextBox_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.inventoryUnlockable);
            this.groupBox1.Controls.Add(this.whistleUnlockable);
            this.groupBox1.Controls.Add(this.HQteleportUnlockable);
            this.groupBox1.Controls.Add(this.mapUnlockable);
            this.groupBox1.Location = new System.Drawing.Point(620, 42);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(127, 215);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Unlockables";
            // 
            // inventoryUnlockable
            // 
            this.inventoryUnlockable.AutoSize = true;
            this.inventoryUnlockable.Location = new System.Drawing.Point(6, 34);
            this.inventoryUnlockable.Name = "inventoryUnlockable";
            this.inventoryUnlockable.Size = new System.Drawing.Size(88, 21);
            this.inventoryUnlockable.TabIndex = 3;
            this.inventoryUnlockable.Text = "Inventory";
            this.inventoryUnlockable.UseVisualStyleBackColor = true;
            // 
            // whistleUnlockable
            // 
            this.whistleUnlockable.AutoSize = true;
            this.whistleUnlockable.Location = new System.Drawing.Point(6, 88);
            this.whistleUnlockable.Name = "whistleUnlockable";
            this.whistleUnlockable.Size = new System.Drawing.Size(116, 21);
            this.whistleUnlockable.TabIndex = 2;
            this.whistleUnlockable.Text = "Puffle Whistle";
            this.whistleUnlockable.UseVisualStyleBackColor = true;
            // 
            // HQteleportUnlockable
            // 
            this.HQteleportUnlockable.AutoSize = true;
            this.HQteleportUnlockable.Location = new System.Drawing.Point(6, 115);
            this.HQteleportUnlockable.Name = "HQteleportUnlockable";
            this.HQteleportUnlockable.Size = new System.Drawing.Size(105, 21);
            this.HQteleportUnlockable.TabIndex = 1;
            this.HQteleportUnlockable.Text = "Spy Gadget";
            this.HQteleportUnlockable.UseVisualStyleBackColor = true;
            // 
            // mapUnlockable
            // 
            this.mapUnlockable.AutoSize = true;
            this.mapUnlockable.Location = new System.Drawing.Point(6, 61);
            this.mapUnlockable.Name = "mapUnlockable";
            this.mapUnlockable.Size = new System.Drawing.Size(57, 21);
            this.mapUnlockable.TabIndex = 0;
            this.mapUnlockable.Text = "Map";
            this.mapUnlockable.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.puffleKlutzy);
            this.groupBox3.Controls.Add(this.puffleChill);
            this.groupBox3.Controls.Add(this.puffleChirp);
            this.groupBox3.Controls.Add(this.puffleFlit);
            this.groupBox3.Controls.Add(this.pufflePop);
            this.groupBox3.Controls.Add(this.puffleLoop);
            this.groupBox3.Controls.Add(this.puffleFlare);
            this.groupBox3.Controls.Add(this.puffleBlast);
            this.groupBox3.Controls.Add(this.puffleBouncer);
            this.groupBox3.Location = new System.Drawing.Point(430, 42);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(184, 215);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Puffles";
            // 
            // puffleKlutzy
            // 
            this.puffleKlutzy.AutoSize = true;
            this.puffleKlutzy.Location = new System.Drawing.Point(95, 112);
            this.puffleKlutzy.Name = "puffleKlutzy";
            this.puffleKlutzy.Size = new System.Drawing.Size(68, 21);
            this.puffleKlutzy.TabIndex = 16;
            this.puffleKlutzy.Text = "Klutzy";
            this.puffleKlutzy.UseVisualStyleBackColor = true;
            // 
            // puffleChill
            // 
            this.puffleChill.AutoSize = true;
            this.puffleChill.Location = new System.Drawing.Point(95, 85);
            this.puffleChill.Name = "puffleChill";
            this.puffleChill.Size = new System.Drawing.Size(56, 21);
            this.puffleChill.TabIndex = 15;
            this.puffleChill.Text = "Chill";
            this.puffleChill.UseVisualStyleBackColor = true;
            // 
            // puffleChirp
            // 
            this.puffleChirp.AutoSize = true;
            this.puffleChirp.Location = new System.Drawing.Point(95, 56);
            this.puffleChirp.Name = "puffleChirp";
            this.puffleChirp.Size = new System.Drawing.Size(63, 21);
            this.puffleChirp.TabIndex = 14;
            this.puffleChirp.Text = "Chirp";
            this.puffleChirp.UseVisualStyleBackColor = true;
            // 
            // puffleFlit
            // 
            this.puffleFlit.AutoSize = true;
            this.puffleFlit.Location = new System.Drawing.Point(95, 29);
            this.puffleFlit.Name = "puffleFlit";
            this.puffleFlit.Size = new System.Drawing.Size(48, 21);
            this.puffleFlit.TabIndex = 13;
            this.puffleFlit.Text = "Flit";
            this.puffleFlit.UseVisualStyleBackColor = true;
            // 
            // pufflePop
            // 
            this.pufflePop.AutoSize = true;
            this.pufflePop.Location = new System.Drawing.Point(6, 137);
            this.pufflePop.Name = "pufflePop";
            this.pufflePop.Size = new System.Drawing.Size(55, 21);
            this.pufflePop.TabIndex = 12;
            this.pufflePop.Text = "Pop";
            this.pufflePop.UseVisualStyleBackColor = true;
            // 
            // puffleLoop
            // 
            this.puffleLoop.AutoSize = true;
            this.puffleLoop.Location = new System.Drawing.Point(6, 110);
            this.puffleLoop.Name = "puffleLoop";
            this.puffleLoop.Size = new System.Drawing.Size(62, 21);
            this.puffleLoop.TabIndex = 11;
            this.puffleLoop.Text = "Loop";
            this.puffleLoop.UseVisualStyleBackColor = true;
            // 
            // puffleFlare
            // 
            this.puffleFlare.AutoSize = true;
            this.puffleFlare.Location = new System.Drawing.Point(6, 83);
            this.puffleFlare.Name = "puffleFlare";
            this.puffleFlare.Size = new System.Drawing.Size(62, 21);
            this.puffleFlare.TabIndex = 10;
            this.puffleFlare.Text = "Flare";
            this.puffleFlare.UseVisualStyleBackColor = true;
            // 
            // puffleBlast
            // 
            this.puffleBlast.AutoSize = true;
            this.puffleBlast.Location = new System.Drawing.Point(6, 56);
            this.puffleBlast.Name = "puffleBlast";
            this.puffleBlast.Size = new System.Drawing.Size(61, 21);
            this.puffleBlast.TabIndex = 9;
            this.puffleBlast.Text = "Blast";
            this.puffleBlast.UseVisualStyleBackColor = true;
            // 
            // puffleBouncer
            // 
            this.puffleBouncer.AutoSize = true;
            this.puffleBouncer.Location = new System.Drawing.Point(6, 29);
            this.puffleBouncer.Name = "puffleBouncer";
            this.puffleBouncer.Size = new System.Drawing.Size(83, 21);
            this.puffleBouncer.TabIndex = 8;
            this.puffleBouncer.Text = "Bouncer";
            this.puffleBouncer.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.highScore6);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.highScore5);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.highScore4);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.highScore3);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.highScore2);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.highScore1);
            this.groupBox4.Location = new System.Drawing.Point(430, 264);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(317, 179);
            this.groupBox4.TabIndex = 8;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Minigame high scores";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(217, 95);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 17);
            this.label8.TabIndex = 17;
            this.label8.Text = "Snow Trekker";
            // 
            // highScore6
            // 
            this.highScore6.Location = new System.Drawing.Point(224, 115);
            this.highScore6.Maximum = new decimal(new int[] {
            -1,
            0,
            0,
            0});
            this.highScore6.Name = "highScore6";
            this.highScore6.Size = new System.Drawing.Size(77, 22);
            this.highScore6.TabIndex = 16;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(125, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(60, 17);
            this.label9.TabIndex = 15;
            this.label9.Text = "Dancing";
            // 
            // highScore5
            // 
            this.highScore5.Location = new System.Drawing.Point(128, 115);
            this.highScore5.Maximum = new decimal(new int[] {
            -1,
            0,
            0,
            0});
            this.highScore5.Name = "highScore5";
            this.highScore5.Size = new System.Drawing.Size(74, 22);
            this.highScore5.TabIndex = 14;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 95);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 17);
            this.label10.TabIndex = 13;
            this.label10.Text = "Jet Pack";
            // 
            // highScore4
            // 
            this.highScore4.Location = new System.Drawing.Point(13, 115);
            this.highScore4.Maximum = new decimal(new int[] {
            -1,
            0,
            0,
            0});
            this.highScore4.Name = "highScore4";
            this.highScore4.Size = new System.Drawing.Size(95, 22);
            this.highScore4.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(226, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 17);
            this.label7.TabIndex = 11;
            this.label7.Text = "Ice Fishing";
            // 
            // highScore3
            // 
            this.highScore3.Location = new System.Drawing.Point(224, 47);
            this.highScore3.Maximum = new decimal(new int[] {
            -1,
            0,
            0,
            0});
            this.highScore3.Name = "highScore3";
            this.highScore3.Size = new System.Drawing.Size(77, 22);
            this.highScore3.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(125, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 17);
            this.label6.TabIndex = 9;
            this.label6.Text = "Cart Surfer";
            // 
            // highScore2
            // 
            this.highScore2.Location = new System.Drawing.Point(128, 47);
            this.highScore2.Maximum = new decimal(new int[] {
            -1,
            0,
            0,
            0});
            this.highScore2.Name = "highScore2";
            this.highScore2.Size = new System.Drawing.Size(74, 22);
            this.highScore2.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "Snowboarding";
            // 
            // highScore1
            // 
            this.highScore1.Location = new System.Drawing.Point(13, 47);
            this.highScore1.Maximum = new decimal(new int[] {
            -1,
            0,
            0,
            0});
            this.highScore1.Name = "highScore1";
            this.highScore1.Size = new System.Drawing.Size(95, 22);
            this.highScore1.TabIndex = 6;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.inventoryBox);
            this.groupBox5.Location = new System.Drawing.Point(12, 264);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(412, 179);
            this.groupBox5.TabIndex = 9;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Inventory";
            // 
            // inventoryBox
            // 
            this.inventoryBox.FormattingEnabled = true;
            this.inventoryBox.HorizontalScrollbar = true;
            this.inventoryBox.Items.AddRange(new object[] {
            " "});
            this.inventoryBox.Location = new System.Drawing.Point(10, 21);
            this.inventoryBox.MultiColumn = true;
            this.inventoryBox.Name = "inventoryBox";
            this.inventoryBox.ScrollAlwaysVisible = true;
            this.inventoryBox.Size = new System.Drawing.Size(386, 140);
            this.inventoryBox.TabIndex = 0;
            // 
            // containsDownloadable
            // 
            this.containsDownloadable.AutoSize = true;
            this.containsDownloadable.Enabled = false;
            this.containsDownloadable.Location = new System.Drawing.Point(184, 91);
            this.containsDownloadable.Name = "containsDownloadable";
            this.containsDownloadable.Size = new System.Drawing.Size(168, 38);
            this.containsDownloadable.TabIndex = 6;
            this.containsDownloadable.Text = "Contains \r\ndownloadable content";
            this.containsDownloadable.UseVisualStyleBackColor = true;
            this.containsDownloadable.CheckedChanged += new System.EventHandler(this.containsDownloadable_CheckedChanged);
            // 
            // SaveFileEditor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 455);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "SaveFileEditor";
            this.Text = "Save File Editor";
            this.Load += new System.EventHandler(this.SaveFileEditor_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.coinsChooser)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.highScore6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.highScore5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.highScore4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.highScore3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.highScore2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.highScore1)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.ComboBox currentMissionChooser;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.ComboBox colourChooser;
        public System.Windows.Forms.TextBox penguinNameTextBox;
        public System.Windows.Forms.NumericUpDown coinsChooser;
        private System.Windows.Forms.GroupBox groupBox1;
        public System.Windows.Forms.CheckBox mapUnlockable;
        public System.Windows.Forms.CheckBox HQteleportUnlockable;
        public System.Windows.Forms.CheckBox whistleUnlockable;
        public System.Windows.Forms.CheckBox inventoryUnlockable;
        private System.Windows.Forms.GroupBox groupBox3;
        public System.Windows.Forms.CheckBox puffleBouncer;
        public System.Windows.Forms.CheckBox puffleBlast;
        public System.Windows.Forms.CheckBox puffleFlare;
        public System.Windows.Forms.CheckBox puffleLoop;
        public System.Windows.Forms.CheckBox pufflePop;
        public System.Windows.Forms.CheckBox puffleFlit;
        public System.Windows.Forms.CheckBox puffleChirp;
        public System.Windows.Forms.CheckBox puffleChill;
        public System.Windows.Forms.CheckBox puffleKlutzy;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.NumericUpDown highScore1;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.NumericUpDown highScore2;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.NumericUpDown highScore3;
        private System.Windows.Forms.Label label8;
        public System.Windows.Forms.NumericUpDown highScore6;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.NumericUpDown highScore5;
        private System.Windows.Forms.Label label10;
        public System.Windows.Forms.NumericUpDown highScore4;
        private System.Windows.Forms.GroupBox groupBox5;
        public System.Windows.Forms.CheckedListBox inventoryBox;
        public System.Windows.Forms.CheckBox containsDownloadable;
    }
}