﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EPFExplorer
{
    class rdtfile
    {
        public string arcname;
        public string filename;
        public byte[] filebytes;

        uint filecount;

        public List<archivedfile> archivedfiles = new List<archivedfile>();

        public Dictionary<uint, int> uniquefilemagicsandfreq = new Dictionary<uint, int>();

        public Dictionary<uint, string> knownfilemagic = new Dictionary<uint, string>();

        public int weirdextrabytescount;


        public void ReadRdt()
        {
            using (BinaryReader reader = new BinaryReader(File.Open(filename, FileMode.Open)))
            {
                filecount = reader.ReadUInt32();
                Console.WriteLine(filecount);

                reader.BaseStream.Position = 0x0B;
                for (int i = 0; i < filecount; i++)
                {
                    archivedfile newarchivedfile = new archivedfile();
                    archivedfiles.Add(newarchivedfile);
                   // newarchivedfile.parentarcfile = this;
                    
                    newarchivedfile.offset = reader.ReadUInt32() + 0x05; //because it measures the offset from the end of the rdt flags
                    newarchivedfile.hash = reader.ReadUInt32();
                    newarchivedfile.size = reader.ReadUInt32();
                }



                for (int i = 0; i < archivedfiles.Count; i++)
                {
                    reader.BaseStream.Position = archivedfiles[i].offset;

                    if (archivedfiles[i].size < filebytes.Length)
                    {
                        archivedfiles[i].filebytes = reader.ReadBytes((int)archivedfiles[i].size);
                        archivedfiles[i].checkfilemagic();
                    }

                }

                Console.WriteLine(archivedfiles.Count);

                foreach (uint filemagic in uniquefilemagicsandfreq.Keys)
                {
                    if (knownfilemagic.Keys.Contains(filemagic))
                    {
                        Console.WriteLine(knownfilemagic[filemagic] + " Freq: " + uniquefilemagicsandfreq[filemagic]);
                    }
                    else
                    {
                        Console.WriteLine(filemagic + " Freq: " + uniquefilemagicsandfreq[filemagic]);
                    }
                }

                foreach (archivedfile file in archivedfiles)
                {
                    if (knownfilemagic.ContainsKey(file.filemagic))
                    {
                        if (file.filebytes != null)
                        {
                            File.WriteAllBytes(filename + file.hash + "." + knownfilemagic[file.filemagic], file.filebytes);
                        }
                        if (file.filemagic == 0x4D504200)
                        {
                            Byte[] hashAsBytes = BitConverter.GetBytes(file.hash);
                            //Console.WriteLine(BitConverter.ToString(hashAsBytes));
                        }
                    }
                    else
                    {
                        if (file.filebytes != null)
                        {
                            File.WriteAllBytes(filename + file.hash + "." + file.filemagic.ToString(), file.filebytes);
                        }
                    }
                }
            }
        }
    }
}
