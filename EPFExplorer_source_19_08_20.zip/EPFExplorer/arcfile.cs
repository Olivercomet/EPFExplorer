﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EPFExplorer
{
    public class arcfile
    {
        public string arcname;
        public string filename;
        public byte[] filebytes;

        public uint filecount;

        public List<archivedfile> archivedfiles = new List<archivedfile>();

        public Dictionary<uint, int> uniquefilemagicsandfreq = new Dictionary<uint, int>();

        public Dictionary<uint, string> knownfilemagic = new Dictionary<uint, string>();

        public int weirdextrabytescount;

        public Form1 form1;

        public bool use_filenames = false;

        public arcfile() {
            knownfilemagic.Add(0x74786574, "st");
            knownfilemagic.Add(0x74786500, "stHR");
            knownfilemagic.Add(0x30444D42, "bmd");
            knownfilemagic.Add(0x30414342, "nsbca");
            knownfilemagic.Add(0xAF12, "flc");  //FLIC animation
            knownfilemagic.Add(0x7C1F, "tsb"); //tileset
            knownfilemagic.Add(0x5161754C, "luac");
            knownfilemagic.Add(0x544E4F46, "fnt");
            knownfilemagic.Add(0x4D504200, "mpb");
            knownfilemagic.Add(0x01544452, "rdt");
        }

        public void DisplayFileMagicFreq() {

            foreach (uint filemagic in uniquefilemagicsandfreq.Keys)
            {
                if (knownfilemagic.Keys.Contains(filemagic))
                {
                    Console.WriteLine(knownfilemagic[filemagic] + " Freq: " + uniquefilemagicsandfreq[filemagic]);
                }
                else
                {
                    Console.WriteLine(filemagic + " Freq: " + uniquefilemagicsandfreq[filemagic]);
                }
            }

        }

        public void ExportAll() {
            foreach (archivedfile file in archivedfiles)
            {
                if (knownfilemagic.ContainsKey(file.filemagic))
                {
                    if (file.filebytes != null)
                    {
                        if (file.filename != "" && use_filenames)
                            {
                            File.WriteAllBytes(Path.GetDirectoryName(filename) + "\\" + file.filename.Replace("/", "-"), file.filebytes);
                            }
                        else
                            {
                            File.WriteAllBytes(filename + file.hash + "." + knownfilemagic[file.filemagic], file.filebytes);
                            }
                    }
                    if (file.filemagic == 0x4D504200)
                    {
                        Byte[] hashAsBytes = BitConverter.GetBytes(file.hash);
                        //Console.WriteLine(BitConverter.ToString(hashAsBytes));
                    }
                }
                else
                {
                    if (file.filebytes != null)
                    {
                        if (file.filename != "" && use_filenames)
                            {
                            File.WriteAllBytes(Path.GetDirectoryName(filename) + "\\" + file.filename.Replace("/", "-"), file.filebytes);
                            }
                        else
                            {
                            File.WriteAllBytes(filename + file.hash + "." + file.filemagic.ToString(), file.filebytes);
                            }
                    }
                }
            }
        }

        public void ReadArc()
        {
            using (BinaryReader reader = new BinaryReader(File.Open(filename, FileMode.Open)))
            {
                filecount = reader.ReadUInt32();
                Console.WriteLine(filecount);
                for (int i = 0; i < filecount; i++)
                    {
                    archivedfile newarchivedfile = new archivedfile();
                    archivedfiles.Add(newarchivedfile);
                    newarchivedfile.parentarcfile = this;
                    newarchivedfile.hash = reader.ReadUInt32();
                    newarchivedfile.offset = reader.ReadUInt32();
                    newarchivedfile.size = reader.ReadUInt32();
                    }

                foreach (string s in form1.filenames_and_hashes.Keys)   //go through the filenames and label the files in the arc as best we can
                    {
                    int targetFileIndex = form1.Find_Closest_File_To(form1.filenames_and_hashes[s], this);

                    if (targetFileIndex < filecount)
                        {
                        if (archivedfiles[targetFileIndex].filename != "")
                            {
                            Console.WriteLine(archivedfiles[targetFileIndex].filename +" and " + s + " are contesting!");
                            }


                        archivedfiles[targetFileIndex].filename = s;

                        if (archivedfiles[targetFileIndex].hash == 0x521FF749)
                            {
                            Console.WriteLine("This should only appear once. The string is "+s);
                            }


                        if (s.ToLower() == "/ui/conversationsystem/borderpanels/npcchatbubblebrdr")
                        {
                            Console.WriteLine("hey, the hash was " + form1.filenames_and_hashes[s] + " and the closest found in the arc was "+archivedfiles[targetFileIndex].hash);
                        }

                        }
                    }


                for (int i = 0; i < archivedfiles.Count; i++)
                    {
                    reader.BaseStream.Position = archivedfiles[i].offset;


                    if (archivedfiles[i].size > 0x80000000 && i < archivedfiles.Count - 1)  //THIS WORKS FOR NOW, BUT IS PROBABLY NOT WHAT YOU'RE MEANT TO DO WITH THESE WEIRD SIZE VALUES WHEN THEY CROP UP, DO THEY INDICATE COMPRESSION? THAT'S FINE HERE AS THEY GET DECOMPRESSED ANYWAY, BUT IF YOU WANT TO WRITE NEW ARC FILES THEN YOU NEED TO FIND OUT HOW THIS WORKS
                        {
                        archivedfiles[i].size = archivedfiles[i + 1].offset - archivedfiles[i].offset;
                        }

                    if (archivedfiles[i].size < filebytes.Length)
                        {
                        reader.BaseStream.Position = archivedfiles[i].offset;
                        archivedfiles[i].filebytes = reader.ReadBytes((int)archivedfiles[i].size);

                        archivedfiles[i].checkfilemagic();
                        }
                    
                    }

                Console.WriteLine(archivedfiles.Count);

                DisplayFileMagicFreq();

                ExportAll();
             }
        }
    }
}
