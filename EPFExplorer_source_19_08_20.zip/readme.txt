A tool for extracting/modifying the files of the Elite Penguin Force DS games.

Current features:

Dumping the contents of arc files.
Dumping audio clips.
Editing save files. (Both EPF and HR)




