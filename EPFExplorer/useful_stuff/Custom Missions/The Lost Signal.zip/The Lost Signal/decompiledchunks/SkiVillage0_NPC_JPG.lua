if _util.GetReason() == _const.CREATED then
  _util.AddInterest(_const.COMMUNICATOR)
end
if _util.GetReason() == _const.TOUCHED then
  if _util.GetConversationCount() == 0 then
    _util.AddConversation(56, 57, -1, _const.CHANGE_DIALOG, 1)
  elseif _util.GetConversationCount() == 1 then
    _util.AddConversation(58, 59, -1, _const.END_DIALOG, 2)
  elseif _util.GetConversationCount() == 2 then
    _util.AddDialog(60, _const.END_DIALOG, 2)
  end
end
