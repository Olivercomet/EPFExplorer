local L0, L1, L2
L0 = _util
L0 = L0.SetupDownloadCutscene
L1 = 0
L2 = 1
L0(L1, L2)
L0 = _util
L0 = L0.SetNextRoom
L1 = 13
L0(L1)
