_util.SetupDownloadCutscene(0, 1)
_util.SetNextRoom(13)
