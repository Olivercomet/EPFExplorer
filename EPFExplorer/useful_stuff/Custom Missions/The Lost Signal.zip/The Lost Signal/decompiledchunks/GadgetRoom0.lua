local L0, L1, L2, L3, L4, L5
L0 = _util
L0 = L0.GetActiveMission
L0 = L0()
L1 = _util
L1 = L1.GetActiveChapter
L1 = L1()
L2 = 34503
L3 = _util
L3 = L3.GetVar
L4 = "downloadIntro"
L3 = L3(L4)
if L3 == 0 then
  L3 = _util
  L3 = L3.DisableSpyPodFunc
  L4 = _const
  L4 = L4.FLAG_SNOWCAT
  L3(L4)
  L3 = _util
  L3 = L3.DisableSpyPodFunc
  L4 = _const
  L4 = L4.FLAG_COMMUNICATOR
  L3(L4)
  L3 = _util
  L3 = L3.DisableSpyPodFunc
  L4 = _const
  L4 = L4.FLAG_HEADQUARTERS
  L3(L4)
  L3 = _util
  L3 = L3.SetPuffle
  L4 = 2000007
  L3(L4)
  L3 = _util
  L3 = L3.ActivateNpc
  L4 = L2
  L5 = 0
  L3(L4, L5)
  L3 = _util
  L3 = L3.SetVar
  L4 = "downloadIntro"
  L5 = 1
  L3(L4, L5)
  L3 = _util
  L3 = L3.ClearObjective
  L3()
end
