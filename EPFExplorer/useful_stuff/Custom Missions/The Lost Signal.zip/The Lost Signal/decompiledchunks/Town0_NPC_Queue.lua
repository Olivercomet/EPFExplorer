local L0, L1, L2, L3, L4, L5, L6, L7, L8, L9
L0 = _util
L0 = L0.GetReason
L0 = L0()
L1 = _const
L1 = L1.CREATED
if L0 == L1 then
  L0 = _util
  L0 = L0.AddInterest
  L1 = _const
  L1 = L1.COMMUNICATOR
  L0(L1)
end
L0 = _util
L0 = L0.GetActiveMission
L0 = L0()
L1 = _util
L1 = L1.GetActiveChapter
L1 = L1()
L2 = _util
L2 = L2.GetConversationCount
L2 = L2()
L3 = 32018
L4 = _util
L4 = L4.GetReason
L4 = L4()
L5 = _const
L5 = L5.TOUCHED
if L4 == L5 then
  if L2 == 0 then
    L4 = _util
    L4 = L4.AddConversation
    L5 = 34
    L6 = 25
    L7 = -1
    L8 = _const
    L8 = L8.CHANGE_DIALOG
    L9 = 1
    L4(L5, L6, L7, L8, L9)
  elseif L2 == 1 then
    L4 = _util
    L4 = L4.AddConversation
    L5 = 26
    L6 = 27
    L7 = -1
    L8 = _const
    L8 = L8.CHANGE_DIALOG
    L9 = 2
    L4(L5, L6, L7, L8, L9)
  elseif L2 == 2 then
    L2 = _util
    L2 = L2.AddDialog
    L3 = 28
    L4 = _const
    L4 = L4.END_DIALOG
    L5 = 2
    L2(L3, L4, L5)
  end
end
L4 = _util
L4 = L4.GetReason
L4 = L4()
L5 = _const
L5 = L5.COMMUNICATOR
if L4 == L5 then
  L4 = _util
  L4 = L4.GetComCount
  L4 = L4()
end