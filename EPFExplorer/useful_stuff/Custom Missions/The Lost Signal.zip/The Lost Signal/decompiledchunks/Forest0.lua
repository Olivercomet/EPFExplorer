local L0, L1, L2, L3, L4, L5
L0 = _util
L0 = L0.GetActiveMission
L0 = L0()
L1 = _util
L1 = L1.GetActiveChapter
L1 = L1()