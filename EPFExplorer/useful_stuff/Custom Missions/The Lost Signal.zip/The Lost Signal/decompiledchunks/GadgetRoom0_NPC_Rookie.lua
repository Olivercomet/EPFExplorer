local L0, L1, L2, L3, L4, L5, L6, L7, L8, L9
L0 = _util
L0 = L0.GetReason
L0 = L0()
L1 = _const
L1 = L1.CREATED
if L0 == L1 then
  L0 = _util
  L0 = L0.AddInterest
  L1 = _const
  L1 = L1.COMMUNICATOR
  L0(L1)
end
L0 = _util
L0 = L0.GetActiveMission
L0 = L0()
L1 = _util
L1 = L1.GetActiveChapter
L1 = L1()
L2 = _util
L2 = L2.GetConversationCount
L2 = L2()
L3 = 32018
L4 = _util
L4 = L4.GetReason
L4 = L4()
L5 = _const
L5 = L5.TOUCHED

L6 = _util
L6 = L6.GetVar
L7 = "LookedAtTransmitter"
L6 = L6(L7)

if L4 == L5 then
  if L6 == 0 then
	  if L2 == 0 then
		L4 = _util
		L4 = L4.AddConversation
		L5 = 14
		L6 = 15
		L7 = -1
		L8 = _const
		L8 = L8.CHANGE_DIALOG
		L9 = 1
		L4(L5, L6, L7, L8, L9)
	  elseif L2 == 1 then
		L2 = _util
		L2 = L2.AddLoopingConv
		L3 = 16
		L2(L3)
		L2 = _util
		L2 = L2.AddLoopingOption
		L3 = 17
		L4 = 18
		L5 = _const
		L5 = L5.UPDATE_LOOP
		L2(L3, L4, L5)
		L2 = _util
		L2 = L2.AddLoopingOption
		L3 = 19
		L4 = -1
		L5 = _const
		L5 = L5.CHANGE_DIALOG
		L6 = 2
		L2(L3, L4, L5, L6)
	  elseif L2 == 2 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 20
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 3
		L2(L3, L4, L5)
	  elseif L2 == 3 then
		L4 = _util
		L4 = L4.AddConversation
		L5 = 21
		L6 = 22
		L7 = -1
		L8 = _const
		L8 = L8.CHANGE_DIALOG
		L9 = 4
		L4(L5, L6, L7, L8, L9)
	  elseif L2 == 4 then
		L4 = _util
		L4 = L4.SetObjective
		L5 = 207
		L4(L5)
		L4 = _util
		L4 = L4.AddDialog
		L5 = 23
		L6 = _const
		L6 = L6.END_DIALOG
		L7 = 5
		L4(L5, L6, L7)
	  else
		L2 = _util
		L2 = L2.AddDialog
		L3 = 24
		L4 = _const
		L4 = L4.END_DIALOG
		L5 = 5
		L2(L3, L4, L5)
	  end
  else
     if L2 == 5 then
		L4 = _util
		L4 = L4.AddConversation
		L5 = 35
		L6 = 36
		L7 = -1
		L8 = _const
		L8 = L8.CHANGE_DIALOG
		L9 = 6
		L4(L5, L6, L7, L8, L9)
	 elseif L2 == 6 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 37
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 7
		L2(L3, L4, L5)
	 elseif L2 == 7 then
		L4 = _util
		L4 = L4.AddConversation
		L5 = 38
		L6 = 39
		L7 = -1
		L8 = _const
		L8 = L8.CHANGE_DIALOG
		L9 = 8
		L4(L5, L6, L7, L8, L9)
	 elseif L2 == 8 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 40
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 9
		L2(L3, L4, L5)
	elseif L2 == 9 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 41
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 10
		L2(L3, L4, L5)
	elseif L2 == 10 then
		L4 = _util
		L4 = L4.AddConversation
		L5 = 42
		L6 = 43
		L7 = -1
		L8 = _const
		L8 = L8.CHANGE_DIALOG
		L9 = 11
		L4(L5, L6, L7, L8, L9)
	elseif L2 == 11 then
		L4 = _util
		L4 = L4.AddConversation
		L5 = 44
		L6 = 45
		L7 = -1
		L8 = _const
		L8 = L8.CHANGE_DIALOG
		L9 = 12
		L4(L5, L6, L7, L8, L9)	
	elseif L2 == 12 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 46
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 13
		L2(L3, L4, L5)
	elseif L2 == 13 then
		L4 = _util
		L4 = L4.AddConversation
		L5 = 47
		L6 = 48
		L7 = -1
		L8 = _const
		L8 = L8.CHANGE_DIALOG
		L9 = 14
		L4(L5, L6, L7, L8, L9)	
	elseif L2 == 14 then
	  L0 = _util
      L0 = L0.AddDialog
      L1 = 49
      L2 = _const
      L2 = L2.END_MISSION
      L0(L1, L2)
	  end
  end
end