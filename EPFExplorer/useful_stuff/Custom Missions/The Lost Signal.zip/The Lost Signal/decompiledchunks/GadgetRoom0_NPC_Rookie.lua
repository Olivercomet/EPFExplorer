if _util.GetReason() == _const.CREATED then
  _util.AddInterest(_const.COMMUNICATOR)
end
if _util.GetReason() == _const.TOUCHED then
  if _util.GetVar("LookedAtTransmitter") == 0 then
    if _util.GetConversationCount() == 0 then
      _util.AddConversation(14, 15, -1, _const.CHANGE_DIALOG, 1)
    elseif _util.GetConversationCount() == 1 then
      _util.AddLoopingConv(16)
      _util.AddLoopingOption(17, 18, _const.UPDATE_LOOP)
      _util.AddLoopingOption(19, -1, _const.CHANGE_DIALOG, 2)
    elseif _util.GetConversationCount() == 2 then
      _util.AddDialog(20, _const.CHANGE_DIALOG, 3)
    elseif _util.GetConversationCount() == 3 then
      _util.AddConversation(21, 22, -1, _const.CHANGE_DIALOG, 4)
    elseif _util.GetConversationCount() == 4 then
      _util.SetObjective(207)
      _util.AddDialog(23, _const.END_DIALOG, 5)
    else
      _util.AddDialog(24, _const.END_DIALOG, 5)
    end
  elseif _util.GetConversationCount() == 5 then
    _util.AddConversation(35, 36, -1, _const.CHANGE_DIALOG, 6)
  elseif _util.GetConversationCount() == 6 then
    _util.AddDialog(37, _const.CHANGE_DIALOG, 7)
  elseif _util.GetConversationCount() == 7 then
    _util.AddConversation(38, 39, -1, _const.CHANGE_DIALOG, 8)
  elseif _util.GetConversationCount() == 8 then
    _util.AddDialog(40, _const.CHANGE_DIALOG, 9)
  elseif _util.GetConversationCount() == 9 then
    _util.AddDialog(41, _const.CHANGE_DIALOG, 10)
  elseif _util.GetConversationCount() == 10 then
    _util.AddConversation(42, 43, -1, _const.CHANGE_DIALOG, 11)
  elseif _util.GetConversationCount() == 11 then
    _util.AddConversation(44, 45, -1, _const.CHANGE_DIALOG, 12)
  elseif _util.GetConversationCount() == 12 then
    _util.AddDialog(46, _const.CHANGE_DIALOG, 13)
  elseif _util.GetConversationCount() == 13 then
    _util.AddConversation(47, 48, -1, _const.CHANGE_DIALOG, 14)
  elseif _util.GetConversationCount() == 14 then
    _util.AddDialog(49, _const.END_MISSION)
  end
end
