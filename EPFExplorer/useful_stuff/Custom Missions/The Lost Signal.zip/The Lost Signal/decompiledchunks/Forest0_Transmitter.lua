if _util.GetReason() == _const.CREATED then
  _util.AddInterest(_const.COMMUNICATOR)
end
if _util.GetReason() == _const.TOUCHED then
  if _util.GetConversationCount() == 0 then
    _util.AddMonologue(29, "DownloadStrings", _const.CHANGE_DIALOG, 1)
  elseif _util.GetConversationCount() == 1 then
    _util.AddMonologue(30, "DownloadStrings", _const.CHANGE_DIALOG, 2)
  elseif _util.GetConversationCount() == 2 then
    _util.AddMonologue(31, "DownloadStrings", _const.CHANGE_DIALOG, 3)
  elseif _util.GetConversationCount() == 3 then
    _util.SetObjective(208)
    _util.SetVar("LookedAtTransmitter", 1)
    _util.HideMap()
    _util.AddMonologue(32, "DownloadStrings")
  else
    _util.AddMonologue(33, "DownloadStrings")
  end
end
