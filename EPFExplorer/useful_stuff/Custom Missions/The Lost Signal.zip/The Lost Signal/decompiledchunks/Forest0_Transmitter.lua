local L0, L1, L2, L3, L4, L5, L6, L7, L8, L9
L0 = _util
L0 = L0.GetReason
L0 = L0()
L1 = _const
L1 = L1.CREATED
if L0 == L1 then
  L0 = _util
  L0 = L0.AddInterest
  L1 = _const
  L1 = L1.COMMUNICATOR
  L0(L1)
end
L0 = _util
L0 = L0.GetActiveMission
L0 = L0()
L1 = _util
L1 = L1.GetActiveChapter
L1 = L1()
L2 = _util
L2 = L2.GetVar
L6 = "LookedAtTransmitter"
L2 = L2(L6)
L3 = 32018
L4 = _util
L4 = L4.GetReason
L4 = L4()
L5 = _const
L5 = L5.TOUCHED

L0 = _util
L0 = L0.GetConversationCount
L0 = L0()

if L4 == L5 then
  if L0 == 0 then
	L1 = _util
    L1 = L1.AddMonologue
    L2 = 29
    L3 = "DownloadStrings"
    L4 = _const
    L4 = L4.CHANGE_DIALOG
    L5 = 1
    L1(L2, L3, L4, L5)
  elseif L0 == 1 then
	L1 = _util
    L1 = L1.AddMonologue
    L2 = 30
    L3 = "DownloadStrings"
    L4 = _const
    L4 = L4.CHANGE_DIALOG
    L5 = 2
    L1(L2, L3, L4, L5)
  elseif L0 == 2 then
	L1 = _util
    L1 = L1.AddMonologue
    L2 = 31
    L3 = "DownloadStrings"
    L4 = _const
    L4 = L4.CHANGE_DIALOG
    L5 = 3
    L1(L2, L3, L4, L5)
  elseif L0 == 3 then
  	L1 = _util
    L1 = L1.SetObjective
    L2 = 208
    L1(L2)
	L1 = _util
	L1 = L1.SetVar
	L2 = "LookedAtTransmitter"
	L3 = 1
	L1(L2,L3)
	L1 = _util
	L1 = L1.HideMap
	L1()
	L1 = _util
    L1 = L1.AddMonologue
    L2 = 32
    L3 = "DownloadStrings"
    L1(L2, L3)
  else
    L1 = _util
    L1 = L1.AddMonologue
    L2 = 33
    L3 = "DownloadStrings"
    L1(L2, L3)
  end
end