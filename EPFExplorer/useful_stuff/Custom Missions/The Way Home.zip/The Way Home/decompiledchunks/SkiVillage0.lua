_util.SetCursorPos(516, 166, 166)
if _util.GetVar("downloadIntro") == 0 then
  _util.DisableSpyPodFunc(_const.FLAG_SNOWCAT)
  _util.DisableSpyPodFunc(_const.FLAG_COMMUNICATOR)
  _util.DisableSpyPodFunc(_const.FLAG_HEADQUARTERS)
  _util.SetPuffle(2000007)
  _util.HideMap()
  _util.ActivateNpc(34503, 0)
  _util.SetVar("downloadIntro", 1)
  _util.ClearObjective()
end
