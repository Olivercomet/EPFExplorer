local L0, L1, L2

L0 = _util
L0 = L0.SetCursorPos
L1 = 516
L2 = 166
L0(L1,L2,L2)

L1 = _util
L1 = L1.GetVar
L2 = "downloadIntro"
L1 = L1(L2)

L0 = 34503

if L1 == 0 then
  L1 = _util
  L1 = L1.DisableSpyPodFunc
  L2 = _const
  L2 = L2.FLAG_SNOWCAT
  L1(L2)
  L1 = _util
  L1 = L1.DisableSpyPodFunc
  L2 = _const
  L2 = L2.FLAG_COMMUNICATOR
  L1(L2)
  L1 = _util
  L1 = L1.DisableSpyPodFunc
  L2 = _const
  L2 = L2.FLAG_HEADQUARTERS
  L1(L2)
  L1 = _util
  L1 = L1.SetPuffle
  L2 = 2000007
  L1(L2)
  L1 = _util
  L1 = L1.HideMap
  L1()
  L1 = _util
  L1 = L1.ActivateNpc
  L2 = 0
  L1(L0, L2)
  L0 = _util
  L0 = L0.SetVar
  L1 = "downloadIntro"
  L2 = 1
  L0(L1, L2)
  L1 = _util
  L1 = L1.ClearObjective
  L1()
end
