local L0, L1, L2, L3, L4, L5

L3 = _util
L3 = L3.GetVar
L3 = L3("LookForSupplies")

L1 = _util
L1 = L1.GetReason
L1 = L1()
L2 = _const
L2 = L2.TOUCHED

if (L3 == 1) then
	if L1 == L2 then
	  L1 = _util
	  L1 = L1.GetConversationCount
	  L1 = L1()
	  if L1 == 0 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 46	--Hey there. How can I help?
		L2(L3)
		L2 = _util
		L2 = L2.AddDialogButton
		L3 = 47 --I’m trying to find supplies for a long journey. Would the Coffee Shop be able to supply anything?
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 1
		L2(L3, L4, L5)
	  elseif L1 == 1 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 48 	--Actually, yes! I’ve finally finished brewing a huge batch of cream soda coffee.
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 2
		L2(L3, L4, L5)
	  elseif L1 == 2 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 49 	--The only problem is, it keeps exploding on the customers! It’s just too volatile.
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 3
		L2(L3, L4, L5)
	  elseif L1 == 3 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 50	--You’re welcome to take it off my hands.
		L2(L3)
		L2 = _util
		L2 = L2.AddDialogButton
		L3 = 51 --Thanks a lot! This should be useful.
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 4
		L2(L3, L4, L5)
	  elseif L1 == 4 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 52 	--Happy to help
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 5
		L2(L3, L4, L5)
	   elseif L1 == 5 then
		  L0 = _util
		  L0 = L0.SetConversationCount
		  L1 = 6
		  L0(L1)
		  L1 = _util
		  L1 = L1.SetVar
		  L2 = "HaveCreamSoda"
		  L3 = 1
		  L1(L2,L3)
		  L0 = _util
		  L0 = L0.SetItemPopUpText
		  L1 = 39585
		  L2 = 4
		  L0(L1, L2)
		  L0 = _util
		  L0 = L0.AddInventoryItem
		  L1 = 39585
		  L0(L1)
		  
		  L0 = _util
			L0 = L0.GetVar
			L1 = L0("HavePizza")
			L2 = L0("HaveRope")
			
			if L1 == 1 and L2 == 1 then
			L0 = _util
			L0 = L0.SetObjective
			L1 = 138	--return to captain rockhopper
			L0(L1)
			end
	   else
		L2 = _util
		L2 = L2.AddDialog
		L3 = 148	--Now I need a new idea... Hmm... what about hot sauce?
		L4 = _const
		L4 = L4.END_DIALOG
		L5 = 6
		L2(L3, L4, L5)
	   end
	end
end
