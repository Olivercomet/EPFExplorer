if _util.GetVar("LookForSupplies") == 1 and _util.GetReason() == _const.TOUCHED then
  if _util.GetConversationCount() == 0 then
    _util.AddDialog(46)
    _util.AddDialogButton(47, _const.CHANGE_DIALOG, 1)
  elseif _util.GetConversationCount() == 1 then
    _util.AddDialog(48, _const.CHANGE_DIALOG, 2)
  elseif _util.GetConversationCount() == 2 then
    _util.AddDialog(49, _const.CHANGE_DIALOG, 3)
  elseif _util.GetConversationCount() == 3 then
    _util.AddDialog(50)
    _util.AddDialogButton(51, _const.CHANGE_DIALOG, 4)
  elseif _util.GetConversationCount() == 4 then
    _util.AddDialog(52, _const.CHANGE_DIALOG, 5)
  elseif _util.GetConversationCount() == 5 then
    _util.SetConversationCount(6)
    _util.SetVar("HaveCreamSoda", 1)
    _util.SetItemPopUpText(39585, 4)
    _util.AddInventoryItem(39585)
    if _util.GetVar("HavePizza") == 1 and _util.GetVar("HaveRope") == 1 then
      _util.SetObjective(138)
    end
  else
    _util.AddDialog(148, _const.END_DIALOG, 6)
  end
end
