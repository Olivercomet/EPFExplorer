local L0, L1, L2, L3, L4, L5

L4 = _util
L4 = L4.GetReason
L4 = L4()
L5 = _const
L5 = L5.TOUCHED

L0 = _util
L0 = L0.GetConversationCount
L0 = L0()

if L4 == L5 then
  if L0 == 0 then
	L1 = _util
    L1 = L1.AddMonologue
    L2 = 27
    L3 = "DownloadStrings"
    L4 = _const
    L4 = L4.CHANGE_DIALOG
    L5 = 1
    L1(L2, L3, L4, L5)
  elseif L0 == 1 then
	L1 = _util
    L1 = L1.AddMonologue
    L2 = 28
    L3 = "DownloadStrings"
    L4 = _const
    L4 = L4.END_DIALOG
    L5 = 0
    L1(L2, L3, L4, L5)
  end
end