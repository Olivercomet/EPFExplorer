local L0, L1, L2, L3, L4, L5, L6, L7

L1 = _util
L1 = L1.GetReason
L1 = L1()
L2 = _const
L2 = L2.CREATED

if L1 == L2 then
  L1 = _util
  L1 = L1.AddInterest
  L2 = _const
  L2 = L2.ITEM_DROPPED
  L1(L2)
end

L7 = _util
L7 = L7.GetConversationCount
L7 = L7()

L1 = _util
L1 = L1.GetReason
L1 = L1()
L2 = _const
L2 = L2.ITEM_DROPPED

if L1 == L2 then
  L1 = _util
  L1 = L1.GetSource
  L1 = L1()
  
  if L7 == 21 then	
    if L1 == 39585 then   --thermos
		L4 = _util
		L4 = L4.RemoveInventoryItem
		L4(39585)
		L2 = _util
		L2 = L2.AddDialogButton
		L3 = 112 --Captain, we should have enough cream soda on this ship to blast the migrator back to the mainland!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 22
		L2(L3, L4, L5)
	end
  end
end




L0 = _util
L0 = L0.GetReason
L0 = L0()
L1 = _const
L1 = L1.TOUCHED



if L0 == L1 then
	  if L7 == 0 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 59 	--We’re off! Hoist the mainsail!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 1
		L2(L3, L4, L5)
	  elseif L7 == 1 then
		L1 = _util
		L1 = L1.AddMonologue
		L2 = 60 --how exciting!
		L3 = "DownloadStrings"
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 2
		L1(L2, L3, L4, L5)
	  elseif L7 == 2 then
		L0 = _util
		L0 = L0.SetConversationCount
		L1 = 3
		L0(L1)
		L1 = _util
		L1 = L1.SetObjective
		L2 = 139
		L1(L2)
		L1 = _util
		L1 = L1.AddMonologue
		L2 = 61
		L3 = "DownloadStrings"
		L1(L2, L3)
	  elseif L7 == 3 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 73
		L4 = _const
		L4 = L4.END_DIALOG
		L5 = 3
		L2(L3, L4, L5)
	  elseif L7 == 10 then
	    L2 = _util
		L2 = L2.AddDialog
		L3 = 78 	--Ye won’t get away with this, you scallywag polar bear!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 11
		L2(L3, L4, L5)
	 elseif L7 == 11 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 79 	--To the brig with you!
		L4 = _const
		L4 = L4.CHANGE_NPC	--change to herbert NPC
		L5 = 30808
		L0 = 12
		L2(L3, L4, L5, L0)
	elseif L7 == 12 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 89 	--He’s fallen overboard, [playername]!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 13
		L2(L3, L4, L5)
	elseif L7 == 13 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 90 -- The Migrator must’ve hit somethin’.
		L2(L3)
		L2 = _util
		L2 = L2.AddDialogButton
		L3 = 91 --But he can’t swim!
		L4 = _const
		L4 = L4.CHANGE_NPC
		L5 = 48319 --change to overboard
		L0 = 2
		L2(L3, L4, L5, L0)
	elseif L7 == 14 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 95 -- The Migrator be sinking! We must turn back for Club Penguin now, or we’ll never make it!
		L2(L3)
		L2 = _util
		L2 = L2.AddDialogButton
		L3 = 96 --What about Herbert?
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 15
		L2(L3, L4, L5)
	elseif L7 == 15 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 97 	--We can’t reach him now. His iceberg’s drifting away!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 16
		L2(L3, L4, L5)
	elseif L7 == 16 then
		L1 = _util
		L1 = L1.AddMonologue
		L2 = 98 --Poor herbert!
		L3 = "DownloadStrings"
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 17
		L1(L2, L3, L4, L5)
	elseif L7 == 17 then
		L0 = _util
		L0 = L0.SetConversationCount
		L1 = 18
		L0(L1)
		L1 = _util
		L1 = L1.SetObjective
		L2 = 141
		L1(L2)
		L1 = _util
		L1 = L1.AddMonologue
		L2 = 99	-- I wonder if there's anything I can give him
		L3 = "DownloadStrings"
		L1(L2, L3)
	elseif L7 == 18 then
		L0 = _util
		L0 = L0.SetConversationCount
		L1 = 18
		L0(L1)
		L1 = _util
		L1 = L1.AddMonologue
		L2 = 143 -- I wonder if there's anything I can give herbert
		L3 = "DownloadStrings"
		L1(L2, L3)
	elseif L7 == 20 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 110 	--This old Migrator’s not fast enough! We won’t be able to reach Club Penguin before she sinks.
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 21
		L2(L3, L4, L5)
	elseif L7 == 21 then
		L1 = _util
		L1 = L1.SetObjective
		L2 = 142
		L1(L2)
		L1 = _util
		L1 = L1.AddMonologue
		L2 = 111 -- Do I have anything that can propel the Migrator faster?
		L3 = "DownloadStrings"
		L1(L2, L3)
	elseif L7 == 22 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 113 	--Well blow me down, what a good idea!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 23
		L2(L3, L4, L5)
	elseif L7 == 23 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 114 	--We'll point the barrels astern, and shake 'em open!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 24
		L2(L3, L4, L5)
	elseif L7 == 24 then
		L0 = _util
		L0 = L0.PlaySFX
		L1 = 114
		L0(L1)
		L2 = _util
		L2 = L2.AddDialog
		L3 = 115 	--It’s worked a treat, [playername]. We’re headed back to the island!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 25
		L2(L3, L4, L5)
	elseif L7 == 25 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 116 	--Y’know, fer a landlubber, ye ain’t half resourceful.
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 26
		L2(L3, L4, L5)
	elseif L7 == 26 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 117 -- You’re welcome to join the crew, sailor!
		L2(L3)
		L2 = _util
		L2 = L2.AddDialogButton
		L3 = 118 --Shiver me timbers! Yo ho ho! Batten down the hatches!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 27
		L2(L3, L4, L5)
		L2 = _util
		L2 = L2.AddDialogButton
		L3 = 121 --Thanks Captain! But duty calls… I’m sticking with the EPF!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 29
		L2(L3, L4, L5)
	elseif L7 == 27 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 119 	--...maybe not.
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 28
		L2(L3, L4, L5)
	elseif L7 == 28 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 120 	--Anyway...
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 29
		L2(L3, L4, L5)
	elseif L7 == 29 then
		L2 = _util
		L2 = L2.SetVar
		L2("LookForSupplies",2)
		L2 = _util
		L2 = L2.AddDialog
		L3 = 122 	--Land ho!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 30
		L2(L3, L4, L5)
	elseif L7 == 30 then
		L3 = _util
		L3 = L3.ClearObjective
		L3()
		L3 = _util
		L3 = L3.ChangeRoom
		L4 = 2		--send player to beach
	    L3(L4)
	else
		L2 = _util
		L2 = L2.AddDialog
		L3 = 108 -- Bad news, matey!
		L2(L3)
		L2 = _util
		L2 = L2.AddDialogButton
		L3 = 109 --What’s wrong?
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 20
		L2(L3, L4, L5)
	end
end