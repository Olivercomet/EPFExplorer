if _util.GetReason() == _const.CREATED then
  _util.AddInterest(_const.ITEM_DROPPED)
end
if _util.GetReason() == _const.ITEM_DROPPED and _util.GetConversationCount() == 21 and _util.GetSource() == 39585 then
  _util.RemoveInventoryItem(39585)
  _util.AddDialogButton(112, _const.CHANGE_DIALOG, 22)
end
if _util.GetReason() == _const.TOUCHED then
  if _util.GetConversationCount() == 0 then
    _util.AddDialog(59, _const.CHANGE_DIALOG, 1)
  elseif _util.GetConversationCount() == 1 then
    _util.AddMonologue(60, "DownloadStrings", _const.CHANGE_DIALOG, 2)
  elseif _util.GetConversationCount() == 2 then
    _util.SetConversationCount(3)
    _util.SetObjective(139)
    _util.AddMonologue(61, "DownloadStrings")
  elseif _util.GetConversationCount() == 3 then
    _util.AddDialog(73, _const.END_DIALOG, 3)
  elseif _util.GetConversationCount() == 10 then
    _util.AddDialog(78, _const.CHANGE_DIALOG, 11)
  elseif _util.GetConversationCount() == 11 then
    _util.AddDialog(79, _const.CHANGE_NPC, 30808, 12)
  elseif _util.GetConversationCount() == 12 then
    _util.AddDialog(89, _const.CHANGE_DIALOG, 13)
  elseif _util.GetConversationCount() == 13 then
    _util.AddDialog(90)
    _util.AddDialogButton(91, _const.CHANGE_NPC, 48319, 2)
  elseif _util.GetConversationCount() == 14 then
    _util.AddDialog(95)
    _util.AddDialogButton(96, _const.CHANGE_DIALOG, 15)
  elseif _util.GetConversationCount() == 15 then
    _util.AddDialog(97, _const.CHANGE_DIALOG, 16)
  elseif _util.GetConversationCount() == 16 then
    _util.AddMonologue(98, "DownloadStrings", _const.CHANGE_DIALOG, 17)
  elseif _util.GetConversationCount() == 17 then
    _util.SetConversationCount(18)
    _util.SetObjective(141)
    _util.AddMonologue(99, "DownloadStrings")
  elseif _util.GetConversationCount() == 18 then
    _util.SetConversationCount(18)
    _util.AddMonologue(143, "DownloadStrings")
  elseif _util.GetConversationCount() == 20 then
    _util.AddDialog(110, _const.CHANGE_DIALOG, 21)
  elseif _util.GetConversationCount() == 21 then
    _util.SetObjective(142)
    _util.AddMonologue(111, "DownloadStrings")
  elseif _util.GetConversationCount() == 22 then
    _util.AddDialog(113, _const.CHANGE_DIALOG, 23)
  elseif _util.GetConversationCount() == 23 then
    _util.AddDialog(114, _const.CHANGE_DIALOG, 24)
  elseif _util.GetConversationCount() == 24 then
    _util.PlaySFX(114)
    _util.AddDialog(115, _const.CHANGE_DIALOG, 25)
  elseif _util.GetConversationCount() == 25 then
    _util.AddDialog(116, _const.CHANGE_DIALOG, 26)
  elseif _util.GetConversationCount() == 26 then
    _util.AddDialog(117)
    _util.AddDialogButton(118, _const.CHANGE_DIALOG, 27)
    _util.AddDialogButton(121, _const.CHANGE_DIALOG, 29)
  elseif _util.GetConversationCount() == 27 then
    _util.AddDialog(119, _const.CHANGE_DIALOG, 28)
  elseif _util.GetConversationCount() == 28 then
    _util.AddDialog(120, _const.CHANGE_DIALOG, 29)
  elseif _util.GetConversationCount() == 29 then
    _util.SetVar("LookForSupplies", 2)
    _util.AddDialog(122, _const.CHANGE_DIALOG, 30)
  elseif _util.GetConversationCount() == 30 then
    _util.ClearObjective()
    _util.ChangeRoom(2)
  else
    _util.AddDialog(108)
    _util.AddDialogButton(109, _const.CHANGE_DIALOG, 20)
  end
end
