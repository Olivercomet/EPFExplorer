if _util.GetReason() == _const.TOUCHED then
  if _util.GetVar("HaveCreamSoda") == 1 and _util.GetVar("HavePizza") == 1 and _util.GetVar("HaveRope") == 1 then
    if _util.GetConversationCount() < 0 then
      _util.SetConversationCount(0)
    end
    if _util.GetConversationCount() == 0 then
      _util.AddConversation(145, 42, -1, _const.CHANGE_DIALOG, 1)
    elseif _util.GetConversationCount() == 1 then
      _util.AddDialog(43, _const.CHANGE_DIALOG, 2)
    elseif _util.GetConversationCount() == 2 then
      _util.AddLoopingConv(44)
      _util.AddLoopingOption(146, -1, _const.CHANGE_DIALOG, 3)
      _util.AddLoopingOption(147, -1, _const.CHANGE_DIALOG, 4)
    elseif _util.GetConversationCount() == 3 then
      _util.ClearObjective()
      _util.ChangeRoom(3)
    elseif _util.GetConversationCount() == 4 then
      _util.AddDialog(45, _const.END_DIALOG, 0)
    end
  elseif _util.GetConversationCount() == 0 then
    _util.AddConversation(29, 30, -1, _const.CHANGE_DIALOG, 1)
  elseif _util.GetConversationCount() == 1 then
    _util.AddConversation(31, 32, -1, _const.END_DIALOG)
    _util.SetObjective(137)
    _util.SetConversationCount(9)
    _util.SetVar("LookForSupplies", 1)
  else
    _util.AddConversation(145, 144, -1, _const.END_DIALOG)
    _util.SetConversationCount(9)
  end
end
