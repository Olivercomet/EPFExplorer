local L0, L1, L2, L3, L4, L5, L6, L7, L8

L2 = _util
L2 = L2.GetConversationCount
L2 = L2()
L4 = _util
L4 = L4.GetReason
L4 = L4()
L5 = _const
L5 = L5.TOUCHED



if L4 == L5 then
	L3 = _util
	L3 = L3.GetVar
	L3 = L3("HaveCreamSoda")

	L4 = _util
	L4 = L4.GetVar
	L4 = L4("HavePizza")

	L5 = _util
	L5 = L5.GetVar
	L5 = L5("HaveRope")
	if L3 == 1 and L4 == 1 and L5 == 1 then
	    if L2 < 0 then	
			L1 = _util
			L1 = L1.SetConversationCount
			L2 = 0
			L1(L2)
		end
		if L2 == 0 then
			L1 = _util
			L1 = L1.AddConversation
			L2 = 145	--Found anythin', [playername]?
			L3 = 42 -- I've got all the supplies
			L4 = -1
			L5 = _const
			L5 = L5.CHANGE_DIALOG
			L0 = 1
			L1(L2, L3, L4, L5, L0)
		  elseif L2 == 1 then
			L1 = _util
			L1 = L1.AddDialog
			L2 = 43 	--Ya-harr! Anchors aweigh, everyone! We be settin’ sail for the Arctic Circle!
			L3 = _const
			L3 = L3.CHANGE_DIALOG
			L4 = 2
			L1(L2, L3, L4)
		  elseif L2 == 2 then
			L2 = _util
			L2 = L2.AddLoopingConv
			L1 = 44	--are ye ready to leave
			L2(L1)
			L2 = _util
			L2 = L2.AddLoopingOption
			L3 = 146	--let's go
			L4 = -1
			L5 = _const
			L5 = L5.CHANGE_DIALOG
			L1 = 3
			L2(L3, L4, L5, L1)
			L2 = _util
			L2 = L2.AddLoopingOption
			L3 = 147		--not just yet, captain
			L4 = -1
			L5 = _const
			L5 = L5.CHANGE_DIALOG
			L1 = 4
			L2(L3, L4, L5, L1)
		 elseif L2 == 3 then
			 L3 = _util
			 L3 = L3.ClearObjective
			 L3()
			 L3 = _util
			 L3 = L3.ChangeRoom
			 L4 = 3		--send player to migrator
			 L3(L4)
		 elseif L2 == 4 then
			L2 = _util
			L2 = L2.AddDialog
			L3 = 45	--arr that be fine
			L4 = _const
			L4 = L4.END_DIALOG
			L5 = 0
			L2(L3, L4, L5)
			end
	else
	  if L2 == 0 then
		L1 = _util
		L1 = L1.AddConversation
		L2 = 29	-- Ooh-arr! I wasn't expectin' to be leavin’ so soon!
		L3 = 30 -- Anything I can do to help?
		L4 = -1
		L5 = _const
		L5 = L5.CHANGE_DIALOG
		L0 = 1
		L1(L2, L3, L4, L5, L0)
	  elseif L2 == 1 then
		L1 = _util
		L1 = L1.AddConversation
		L2 = 31	--Aye. We'll need extra supplies of pizza, cream soda, and some ropes to tie the lot down!
		L3 =32 -- Aye aye, captain!
		L4 = -1
		L5 = _const
		L5 = L5.END_DIALOG
		L1(L2, L3, L4, L5)
		L0 = _util
		L0 = L0.SetObjective
		L1 = 137	--find supplies of cream soda, pizza, and rope
		L0(L1)
		L1 = _util
		L1 = L1.SetConversationCount
		L2 = 9
		L1(L2)
		L1 = _util
		L1 = L1.SetVar
		L2 = "LookForSupplies"
		L3 = 1
		L1(L2,L3)
	else
		L1 = _util
		L1 = L1.AddConversation
		L2 = 145	--Found anythin', [playername]?
		L3 = 144 -- Not yet, but I'll keep looking.
		L4 = -1
		L5 = _const
		L5 = L5.END_DIALOG
		L1(L2, L3, L4, L5)
		
		L1 = _util
		L1 = L1.SetConversationCount
		L2 = 9
		L1(L2)
	  end
	end
end