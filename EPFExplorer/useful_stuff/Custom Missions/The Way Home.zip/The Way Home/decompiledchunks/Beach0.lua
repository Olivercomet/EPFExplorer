_util.SetCursorPos(1000, 146, 146)
if _util.GetVar("LookForSupplies") == 2 then
  _util.DelItem(49033)
  _util.DelItem(41901)
  _util.AddItem(48186)
  _util.ActivateNpc(48186, 0)
else
  _util.DelItem(48186)
end
