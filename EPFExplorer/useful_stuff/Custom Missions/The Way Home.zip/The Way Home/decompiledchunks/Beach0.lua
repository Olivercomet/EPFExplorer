local L0, L1, L2

L0 = _util
L0 = L0.SetCursorPos
L1 = 1000
L2 = 146
L0(L1,L2,L2)


L1 = _util
L1 = L1.GetVar
L1 = L1("LookForSupplies")

L2 = _util
L2 = L2.DelItem

if L1 == 2 then	--if it's the ending cutscene, delete rockhopper and yarr from beach
	L2(49033)
	L2(41901)
	L2 = _util
	L2 = L2.AddItem
	L2(48186)	--add gary
	L2 = _util
	L2 = L2.ActivateNpc
	L2(48186,0)	--activate gary
else
	L2(48186)	--delete gary
end
