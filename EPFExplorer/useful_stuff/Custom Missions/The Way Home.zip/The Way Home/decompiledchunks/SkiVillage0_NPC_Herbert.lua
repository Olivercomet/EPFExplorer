if _util.GetReason() == _const.CREATED then
  _util.AddInterest(_const.COMMUNICATOR)
end
if _util.GetReason() == _const.TOUCHED then
  if _util.GetVar("SpokeToDirector") == 0 then
    if _util.GetConversationCount() == 0 then
      _util.ActivateNpc(41253, 0)
    elseif _util.GetConversationCount() == 1 then
      _util.AddConversation(16, 17, -1, _const.CHANGE_DIALOG, 2)
    elseif _util.GetConversationCount() == 2 then
      _util.AddDialog(18, _const.CHANGE_DIALOG, 3)
    elseif _util.GetConversationCount() == 3 then
      _util.AddConversation(19, 20, -1, _const.CHANGE_DIALOG, 4)
    elseif _util.GetConversationCount() == 4 then
      _util.AddConversation(21, 22, -1, _const.CHANGE_DIALOG, 5)
    elseif _util.GetConversationCount() == 5 then
      _util.AddDialog(23, _const.CHANGE_DIALOG, 6)
    elseif _util.GetConversationCount() == 6 then
      _util.AddConversation(24, 25, -1, _const.CHANGE_DIALOG, 7)
    elseif _util.GetConversationCount() == 7 then
      _util.AddDialog(26, _const.CHANGE_DIALOG, 8)
    elseif _util.GetConversationCount() == 8 then
      _util.EnableSpyPodFunc(_const.FLAG_COMMUNICATOR)
      _util.ClearCom()
      _util.SetupComNpc(_const.COM_DIRECTOR, 34503, 0)
      _util.SetConversationCount(7)
      _util.SetObjective(134)
      _util.AddMonologue(41, "DownloadStrings")
    end
  elseif _util.GetVar("SpokeToDirector") == 1 then
    if _util.GetConversationCount() == 7 then
      _util.AddConversation(37, 38, -1, _const.CHANGE_DIALOG, 8)
    elseif _util.GetConversationCount() == 8 then
      _util.ClearCom()
      _util.SetObjective(136)
      _util.ChangeRoom(2)
    end
  end
end
if _util.GetReason() == _const.COMMUNICATOR then
  if _util.GetComCount() == 0 then
    _util.AddComText(0)
    _util.AddComOption(1, _const.CHANGE_DIALOG, 1)
  elseif _util.GetComCount() == 1 then
    _util.AddComText(2, _const.CHANGE_DIALOG, 2)
  elseif _util.GetComCount() == 2 then
    _util.AddComText(3, _const.CHANGE_DIALOG, 3)
  elseif _util.GetComCount() == 3 then
    _util.AddComText(4)
    _util.AddComOption(5, _const.CHANGE_DIALOG, 4)
  elseif _util.GetComCount() == 4 then
    _util.AddComText(6, _const.CHANGE_DIALOG, 5)
  elseif _util.GetComCount() == 5 then
    _util.AddComText(7)
    _util.AddComOption(8, _const.CHANGE_DIALOG, 6)
  elseif _util.GetComCount() == 6 then
    _util.SetVar("SpokeToDirector", 1)
    _util.SetObjective(135)
    _util.AddComText(9, _const.END_DIALOG, 0)
  end
end
