local L0, L1, L2, L3, L4, L5, L6, L7, L8, L9
L0 = _util
L0 = L0.GetReason
L0 = L0()
L1 = _const
L1 = L1.CREATED
if L0 == L1 then
  L0 = _util
  L0 = L0.AddInterest
  L1 = _const
  L1 = L1.COMMUNICATOR
  L0(L1)
end
L2 = _util
L2 = L2.GetConversationCount
L2 = L2()
L3 = 32018
L4 = _util
L4 = L4.GetReason
L4 = L4()
L5 = _const
L5 = L5.TOUCHED

L6 = _util
L6 = L6.GetVar
L6 = L6("SpokeToDirector")


if L4 == L5 then
	if L6 == 0 then
	  if L2 == 0 then
		 L3 = _util
		 L3 = L3.ActivateNpc
		 L4 = 41253
		 L5 = 0
		 L3(L4, L5)
	  elseif L2 == 1 then
		L4 = _util
		L4 = L4.AddConversation
		L5 = 16	--greetings
		L6 = 17 --give up the act
		L7 = -1
		L8 = _const
		L8 = L8.CHANGE_DIALOG
		L9 = 2
		L4(L5, L6, L7, L8, L9)
	  elseif L2 == 2 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 18 	--actually agent
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 3
		L2(L3, L4, L5)
	  elseif L2 == 3 then
		L4 = _util
		L4 = L4.AddConversation
		L5 = 19	--it's only fair
		L6 = 20 --alright, what's the favor
		L7 = -1
		L8 = _const
		L8 = L8.CHANGE_DIALOG
		L9 = 4
		L4(L5, L6, L7, L8, L9)
	  elseif L2 == 4 then
		L4 = _util
		L4 = L4.AddConversation
		L5 = 21	--I wish to return home
		L6 = 22 --what! I thought you hated it there
		L7 = -1
		L8 = _const
		L8 = L8.CHANGE_DIALOG
		L9 = 5
		L4(L5, L6, L7, L8, L9)
	  elseif L2 == 5 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 23 	--you're right, I did
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 6
		L2(L3, L4, L5)
	  elseif L2 == 6 then
	    L4 = _util
		L4 = L4.AddConversation
		L5 = 24	--with its loud parties, inedible food
		L6 = 25 --alright, I get it
		L7 = -1
		L8 = _const
		L8 = L8.CHANGE_DIALOG
		L9 = 7
		L4(L5, L6, L7, L8, L9)
	  elseif L2 == 7 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 26	 --thank you, agent. I eagerly await your answer
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 8
		L2(L3, L4, L5)
	  elseif L2 == 8 then
		L4 = _util
		L4 = L4.EnableSpyPodFunc
		L5 = _const
		L5 = L5.FLAG_COMMUNICATOR
		L4(L5)
		
		L4 = _util
		L4 = L4.ClearCom
		L4()
		
		L2 = _util
		L2 = L2.SetupComNpc
		L3 = _const
		L3 = L3.COM_DIRECTOR
		L4 = 34503
		L5 = 0
		L2(L3, L4, L5)
		
		L4 = _util
		L4 = L4.SetConversationCount
		L5 = 7
		L4(L5)
		L1 = _util
		L1 = L1.SetObjective
		L2 = 134		--speak to the director
		L1(L2)
		L1 = _util
		L1 = L1.AddMonologue
		L2 = 41
		L3 = "DownloadStrings"
		L1(L2, L3)
	  end
	elseif L6 == 1 then
	   if L2 == 7 then
		 L4 = _util
		 L4 = L4.AddConversation
		 L5 = 37	--well playername?
		 L6 = 38    --it seems you've got your wish
		 L7 = -1
		 L8 = _const
		 L8 = L8.CHANGE_DIALOG
		 L9 = 8
		 L4(L5, L6, L7, L8, L9)
	   elseif L2 == 8 then
	     L3 = _util
	     L3 = L3.ClearCom
         L3()
		 L3 = _util
		 L3 = L3.SetObjective
		 L4 = 136	--speak to rockhopper
		 L3(L4)
		 L3 = _util
         L3 = L3.ChangeRoom
         L4 = 2		--send player to beach
         L3(L4)
	   end
	end
end

L4 = _util
L4 = L4.GetReason
L4 = L4()
L5 = _const
L5 = L5.COMMUNICATOR

if L4 == L5 then
	L0 = _util
	L0 = L0.GetComCount
	L0 = L0()
  
	if L0 == 0 then
       L1 = _util
       L1 = L1.AddComText
       L2 = 0			--agent playername, what seems to be the problem
       L1(L2)
       L1 = _util
       L1 = L1.AddComOption
       L2 = 1			--herbert wants to go home! should we let him?
       L3 = _const
       L3 = L3.CHANGE_DIALOG
       L4 = 1
       L1(L2, L3, L4)
	elseif L0 == 1 then
	   L1 = _util
       L1 = L1.AddComText
       L2 = 2				-- we can't keep him here against his will
	   L3 = _const
       L3 = L3.CHANGE_DIALOG
       L4 = 2
       L1(L2, L3, L4)
	elseif L0 == 2 then
		L1 = _util
       L1 = L1.AddComText	--and to be honest it's a weight off our shoulders, too
       L2 = 3
	   L3 = _const
       L3 = L3.CHANGE_DIALOG
       L4 = 3
       L1(L2, L3, L4)
	elseif L0 == 3 then
	   L1 = _util
       L1 = L1.AddComText
       L2 = 4			--luckily, rockhopper is in port
       L1(L2)
       L1 = _util
       L1 = L1.AddComOption
       L2 = 5			--thank you, director
       L3 = _const
       L3 = L3.CHANGE_DIALOG
       L4 = 4
       L1(L2, L3, L4)
	elseif L0 == 4 then
	   L1 = _util
       L1 = L1.AddComText
       L2 = 6				-- we'll need an agent on the ship
	   L3 = _const
       L3 = L3.CHANGE_DIALOG
       L4 = 5
       L1(L2, L3, L4)
	elseif L0 == 5 then
	   L1 = _util
       L1 = L1.AddComText
       L2 = 7			--I am assigning you to this task. any questions?
       L1(L2)
       L1 = _util
       L1 = L1.AddComOption
       L2 = 8			--no director
       L3 = _const
       L3 = L3.CHANGE_DIALOG
       L4 = 6
       L1(L2, L3, L4)
    elseif L0 == 6 then
	   L1 = _util
	   L1 = L1.SetVar
	   L2 = "SpokeToDirector"
	   L3 = 1
	   L1(L2,L3)
	   L1 = _util
	   L1 = L1.SetObjective
	   L2 = 135 --return to herbert
	   L1(L2)
       L1 = _util
       L1 = L1.AddComText
       L2 = 9				-- Very well. Please proceed to the Migrator.
	   L3 = _const
       L3 = L3.END_DIALOG
       L4 = 0
       L1(L2, L3, L4)
    end
end