if _util.GetReason() == _const.TOUCHED then
  _util.SetVar("HaveRope", 1)
  _util.SetItemPopUpText(40217, 5)
  _util.AddInventoryItem(40217)
  if _util.GetVar("HavePizza") == 1 and _util.GetVar("HaveCreamSoda") == 1 then
    _util.SetObjective(138)
  end
  _util.DelItem(40217)
end
