local L0, L1, L2
L0 = _util
L0 = L0.GetReason
L0 = L0()
L1 = _const
L1 = L1.TOUCHED

if L0 == L1 then
	L0 = _util
	L0 = L0.SetVar
	L1 = "HaveRope"
	L2 = 1
	L0(L1,L2)
	L0 = _util
	L0 = L0.SetItemPopUpText
	L1 = 40217
	L2 = 5
	L0(L1, L2)
	L0 = _util
	L0 = L0.AddInventoryItem
	L1 = 40217
	L0(L1)
	
	L0 = _util
	L0 = L0.GetVar
	L1 = L0("HavePizza")
	L2 = L0("HaveCreamSoda")
	
	if L1 == 1 and L2 == 1 then
	L0 = _util
	L0 = L0.SetObjective
	L1 = 138	--return to captain rockhopper
	L0(L1)
	end
	
	L0 = _util
	L0 = L0.DelItem
	L0(40217)
end