if _util.GetReason() == _const.TOUCHED then
  if _util.GetConversationCount() == 0 then
    _util.SetConversationCount(1)
    _util.AddConversation(14, 15, -1, _const.CHANGE_NPC, 34503, 1)
  else
    _util.AddConversation(39, 40, -1, _const.END_DIALOG)
  end
end
