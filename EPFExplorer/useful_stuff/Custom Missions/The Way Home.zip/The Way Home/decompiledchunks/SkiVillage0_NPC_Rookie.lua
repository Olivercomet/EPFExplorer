local L0, L1, L2, L3, L4, L5, L6, L7
L0 = _util
L0 = L0.GetReason
L0 = L0()
L1 = _const
L1 = L1.TOUCHED

L7 = _util
L7 = L7.GetConversationCount
L7 = L7()

if L0 == L1 then
	  if L7 == 0 then
		L0 = _util
		L0 = L0.SetConversationCount
		L1 = 1
		L0(L1)
		L0 = _util
		L0 = L0.AddConversation
		L1 = 14		--Herbert!
		L2 = 15		--Herbert. What are you doing here?
		L3 = -1
		L4 = _const
		L4 = L4.CHANGE_NPC	--change to herbert NPC
		L5 = 34503
		L6 = 1
		L0(L1, L2, L3, L4, L5, L6)
	  else
		L0 = _util
		L0 = L0.AddConversation
		L1 = 39	--don't worry playername
		L2 = 40 --thanks rookie
		L3 = -1
		L4 = _const
		L4 = L4.END_DIALOG
		L0(L1, L2, L3, L4)
	  end
end