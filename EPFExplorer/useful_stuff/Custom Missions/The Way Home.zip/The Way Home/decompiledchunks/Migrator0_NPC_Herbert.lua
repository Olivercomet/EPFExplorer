if _util.GetReason() == _const.CREATED then
  _util.AddInterest(_const.ITEM_DROPPED)
end
if _util.GetReason() == _const.ITEM_DROPPED and _util.GetSource() == 40217 and _util.GetConversationCount() == 14 then
  _util.RemoveInventoryItem(40217)
  _util.AddDialog(83)
  _util.AddDialogButton(84, _const.CHANGE_DIALOG, 15)
end
if _util.GetReason() == _const.TOUCHED then
  if _util.GetConversationCount() == 0 then
    _util.AddDialog(62)
    _util.AddDialogButton(63, _const.CHANGE_DIALOG, 1)
  elseif _util.GetConversationCount() == 1 then
    _util.AddDialog(64)
    _util.AddDialogButton(65, _const.CHANGE_DIALOG, 2)
  elseif _util.GetConversationCount() == 2 then
    _util.AddDialog(66, _const.CHANGE_DIALOG, 3)
  elseif _util.GetConversationCount() == 3 then
    _util.AddDialog(67)
    _util.AddDialogButton(68, _const.CHANGE_DIALOG, 4)
  elseif _util.GetConversationCount() == 4 then
    _util.AddDialog(69, _const.CHANGE_DIALOG, 5)
  elseif _util.GetConversationCount() == 5 then
    _util.AddLoopingConv(70)
    _util.AddLoopingOption(71, 72, _const.UPDATE_LOOP, 5)
    _util.AddLoopingOption(74, -1, _const.CHANGE_DIALOG, 6)
  elseif _util.GetConversationCount() == 6 then
    _util.AddDialog(75, _const.CHANGE_DIALOG, 7)
  elseif _util.GetConversationCount() == 7 then
    _util.AddDialog(76, _const.CHANGE_DIALOG, 8)
  elseif _util.GetConversationCount() == 8 then
    _util.AddDialog(77, _const.CHANGE_NPC, 38132, 10)
  elseif _util.GetConversationCount() == 12 then
    _util.AddDialog(80, _const.CHANGE_DIALOG, 13)
  elseif _util.GetConversationCount() == 13 then
    _util.AddDialog(81, _const.CHANGE_DIALOG, 14)
  elseif _util.GetConversationCount() == 14 then
    _util.SetObjective(140)
    _util.AddMonologue(82, "DownloadStrings")
  elseif _util.GetConversationCount() == 15 then
    _util.AddDialog(85)
    _util.AddDialogButton(86, _const.CHANGE_DIALOG, 16)
  elseif _util.GetConversationCount() == 16 then
    _util.ScreenShake(60)
    _util.PlaySFX(114)
    _util.ActivateNpc(48319, 1)
  end
end
