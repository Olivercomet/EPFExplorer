local L0, L1, L2, L3, L4, L5

L1 = _util
L1 = L1.GetReason
L1 = L1()
L2 = _const
L2 = L2.CREATED
if L1 == L2 then
  L1 = _util
  L1 = L1.AddInterest
  L2 = _const
  L2 = L2.ITEM_DROPPED
  L1(L2)
end

L1 = _util
L1 = L1.GetReason
L1 = L1()
L2 = _const
L2 = L2.ITEM_DROPPED
if L1 == L2 then
  L1 = _util
  L1 = L1.GetSource
  L1 = L1()
  if L1 == 40217 then   --rope
	L1 = _util
	L1 = L1.GetConversationCount
	L1 = L1()
	
	if L1 == 14 then	
		L2 = _util
		L2 = L2.RemoveInventoryItem
		L2(40217)	--remove rope
		L2 = _util
		L2 = L2.AddDialog
		L3 = 83	--Ha! You think a rope like this can stop me?
		L2(L3)
		L2 = _util
		L2 = L2.AddDialogButton
		L3 = 84 --Wait a moment, Herbert. I just realised something...
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 15
		L2(L3, L4, L5)
	end
  end
end

L1 = _util
L1 = L1.GetReason
L1 = L1()
L2 = _const
L2 = L2.TOUCHED

	if L1 == L2 then
	  L1 = _util
	  L1 = L1.GetConversationCount
	  L1 = L1()
	  if L1 == 0 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 62	--Hello Agent. Enjoying the voyage?
		L2(L3)
		L2 = _util
		L2 = L2.AddDialogButton
		L3 = 63 --Yeah! How about you?
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 1
		L2(L3, L4, L5)
	  elseif L1 == 1 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 64	--Well, it’s certainly better than my previous trip...
		L2(L3)
		L2 = _util
		L2 = L2.AddDialogButton
		L3 = 65 --So Herbert, how does it feel to be going home?
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 2
		L2(L3, L4, L5)
	  elseif L1 == 2 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 66 	--Oh, my dear Agent, you HAVE been naive…
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 3
		L2(L3, L4, L5)
	  elseif L1 == 3 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 67	--Now that we’re out of reach of your friends at the EPF, I can put my REAL plan into action!
		L2(L3)
		L2 = _util
		L2 = L2.AddDialogButton
		L3 = 68 --Oh no!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 4
		L2(L3, L4, L5)
	  elseif L1 == 4 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 69 	--Listen up, penguins! This ship has a new destination!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 5
		L2(L3, L4, L5)
	  elseif L1 == 5 then
			L2 = _util
			L2 = L2.AddLoopingConv
			L1 = 70	--Set a course for my tropical paradise! The Migrator has joined the Herbert fleet!
			L2(L1)
			L2 = _util
			L2 = L2.AddLoopingOption
			L3 = 71	--How many ships are in this ‘Herbert Fleet’ anyway...?
			L4 = 72 --Um... this one.
			L5 = _const
			L5 = L5.UPDATE_LOOP
			L1 = 5
			L2(L3, L4, L5, L1)
			L2 = _util
			L2 = L2.AddLoopingOption
			L3 = 74		--What about us?
			L4 = -1		
			L5 = _const
			L5 = L5.CHANGE_DIALOG
			L1 = 6
			L2(L3, L4, L5, L1)
		elseif L1 == 6 then
			L2 = _util
			L2 = L2.AddDialog
			L3 = 75 	--Well, since I won’t be giving you your ship back, I suppose you’ll have to stay in paradise.
			L4 = _const
			L4 = L4.CHANGE_DIALOG
			L5 = 7
			L2(L3, L4, L5)
		elseif L1 == 7 then
			L2 = _util
			L2 = L2.AddDialog
			L3 = 76 	--But don’t get your flippers in a twist, Agent. I’m sure you’ll WARM to it over time.
			L4 = _const
			L4 = L4.CHANGE_DIALOG
			L5 = 8
			L2(L3, L4, L5)
		elseif L1 == 8 then
			L2 = _util
			L2 = L2.AddDialog
			L3 = 77 	--However, I strongly advise you to keep out of my way. I’ve had it up to here with you pesky penguins!
			L4 = _const
			L4 = L4.CHANGE_NPC	--change to rockhopper NPC
			L5 = 38132
			L0 = 10
			L2(L3, L4, L5, L0)
		elseif L1 == 12 then
			L2 = _util
			L2 = L2.AddDialog
			L3 = 80 	--Bwa ha ha
			L4 = _const
			L4 = L4.CHANGE_DIALOG
			L5 = 13
			L2(L3, L4, L5)
		elseif L1 == 13 then
			L2 = _util
			L2 = L2.AddDialog
			L3 = 81 	--Get ready to walk the plank, Captain!
			L4 = _const
			L4 = L4.CHANGE_DIALOG
			L5 = 14
			L2(L3, L4, L5)
		elseif L1 == 14 then
		    L1 = _util
			L1 = L1.SetObjective
			L2 = 140
			L1(L2)
			L1 = _util
			L1 = L1.AddMonologue
			L2 = 82 --I need to restrain Herbert somehow!
			L3 = "DownloadStrings"
			L1(L2, L3)
		elseif L1 == 15 then
			L2 = _util
			L2 = L2.AddDialog
			L3 = 85 --Hey! I was speaking! I demand to be heard--
			L2(L3)
			L2 = _util
			L2 = L2.AddDialogButton
			L3 = 86 --While you were both arguing... nobody's been steering the ship!
			L4 = _const
			L4 = L4.CHANGE_DIALOG
			L5 = 16
			L2(L3, L4, L5)
		elseif L1 == 16 then
			L0 = _util
			L0 = L0.ScreenShake
			L1 = 60
			L0(L1)
			L0 = _util
			L0 = L0.PlaySFX
			L1 = 114
			L0(L1)
			L0 = _util
			L0 = L0.ActivateNpc
			L0(48319,1)
	   end
	end
