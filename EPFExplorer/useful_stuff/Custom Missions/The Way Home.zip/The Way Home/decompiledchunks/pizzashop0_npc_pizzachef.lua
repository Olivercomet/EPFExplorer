if _util.GetVar("LookForSupplies") == 1 and _util.GetReason() == _const.TOUCHED then
  if _util.GetConversationCount() == 0 then
    _util.AddDialog(54)
    _util.AddDialogButton(55, _const.CHANGE_DIALOG, 1)
  elseif _util.GetConversationCount() == 1 then
    _util.AddDialog(56, _const.CHANGE_DIALOG, 2)
  elseif _util.GetConversationCount() == 2 then
    _util.AddDialog(57)
    _util.AddDialogButton(58, _const.CHANGE_DIALOG, 3)
  elseif _util.GetConversationCount() == 3 then
    _util.AddLoopingConv(149)
    _util.AddLoopingOption(33, -1, _const.CHANGE_DIALOG, 4)
    _util.AddLoopingOption(34, -1, _const.CHANGE_DIALOG, 6)
    _util.AddLoopingOption(35, -1, _const.CHANGE_DIALOG, 8)
    _util.SetVar("HavePizza", 1)
  elseif _util.GetConversationCount() == 4 then
    _util.AddDialog(150, _const.CHANGE_DIALOG, 5)
  elseif _util.GetConversationCount() == 5 then
    _util.SetConversationCount(10)
    _util.SetItemPopUpText(55924, 33)
    _util.AddInventoryItem(55924)
    _util.HideDialog()
    if _util.GetVar("HaveCreamSoda") == 1 and _util.GetVar("HaveRope") == 1 then
      _util.SetObjective(138)
    end
  elseif _util.GetConversationCount() == 6 then
    _util.AddDialog(151, _const.CHANGE_DIALOG, 7)
  elseif _util.GetConversationCount() == 7 then
    _util.SetConversationCount(10)
    _util.SetItemPopUpText(31099, 34)
    _util.AddInventoryItem(31099)
    _util.HideDialog()
    if _util.GetVar("HaveCreamSoda") == 1 and _util.GetVar("HaveRope") == 1 then
      _util.SetObjective(138)
    end
  elseif _util.GetConversationCount() == 8 then
    _util.AddDialog(152, _const.CHANGE_DIALOG, 9)
  elseif _util.GetConversationCount() == 9 then
    _util.SetConversationCount(10)
    _util.SetItemPopUpText(31084, 35)
    _util.AddInventoryItem(31084)
    _util.HideDialog()
    if _util.GetVar("HaveCreamSoda") == 1 and _util.GetVar("HaveRope") == 1 then
      _util.SetObjective(138)
    end
  else
    _util.AddDialog(10, _const.END_DIALOG, 10)
  end
end
