local L0, L1, L2, L3, L4, L5

L3 = _util
L3 = L3.GetVar
L3 = L3("LookForSupplies")

L1 = _util
L1 = L1.GetReason
L1 = L1()
L2 = _const
L2 = L2.TOUCHED

if (L3 == 1) then
	if L1 == L2 then
	  L1 = _util
	  L1 = L1.GetConversationCount
	  L1 = L1()
	  if L1 == 0 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 54	--Welcome to the Pizza Parlor. May I take your order?
		L2(L3)
		L2 = _util
		L2 = L2.AddDialogButton
		L3 = 55 --I’m gathering supplies for a voyage to the Arctic Circle. Would you be able to supply any pizza?
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 1
		L2(L3, L4, L5)
	  elseif L1 == 1 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 56 	--The Arctic! That’s quite the distance!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 2
		L2(L3, L4, L5)
	  elseif L1 == 2 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 57	--I’ll deliver the pizzas to the beach for you. Could you carry some too?
		L2(L3)
		L2 = _util
		L2 = L2.AddDialogButton
		L3 = 58 --Sure thing!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 3
		L2(L3, L4, L5)
	  elseif L1 == 3 then
		L2 = _util
		L2 = L2.AddLoopingConv
		L1 = 149	--What kind would you like?
		L2(L1)
		L2 = _util
		L2 = L2.AddLoopingOption
		L3 = 33	--hot sauce
		L4 = -1
		L5 = _const
		L5 = L5.CHANGE_DIALOG
		L1 = 4
		L2(L3, L4, L5, L1)
		L2 = _util
		L2 = L2.AddLoopingOption
		L3 = 34		--seaweed
		L4 = -1
		L5 = _const
		L5 = L5.CHANGE_DIALOG
		L1 = 6
		L2(L3, L4, L5, L1)
		L2 = _util
		L2 = L2.AddLoopingOption
		L3 = 35		--squid
		L4 = -1
		L5 = _const
		L5 = L5.CHANGE_DIALOG
		L1 = 8
		L2(L3, L4, L5, L1)
		L1 = _util
		L1 = L1.SetVar
		L2 = "HavePizza"
		L3 = 1
		L1(L2,L3)
	  elseif L1 == 4 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 150 	--hot sauce pizza, coming right up
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 5
		L2(L3, L4, L5)
	  elseif L1 == 5 then
		  L0 = _util
		  L0 = L0.SetConversationCount
		  L1 = 10
		  L0(L1)
		  L0 = _util
		  L0 = L0.SetItemPopUpText
		  L1 = 55924
		  L2 = 33 --hot sauce pizza
		  L0(L1, L2)
		  L0 = _util
		  L0 = L0.AddInventoryItem
		  L1 = 55924
		  L0(L1)
		  L0 = _util
		  L0 = L0.HideDialog
		  L0()
		  
		   L0 = _util
			L0 = L0.GetVar
			L1 = L0("HaveCreamSoda")
			L2 = L0("HaveRope")
			
			if L1 == 1 and L2 == 1 then
			L0 = _util
			L0 = L0.SetObjective
			L1 = 138	--return to captain rockhopper
			L0(L1)
			end
	  elseif L1 == 6 then
		 L2 = _util
		 L2 = L2.AddDialog
		 L3 = 151 	--seaweed pizza, coming right up
		 L4 = _const
		 L4 = L4.CHANGE_DIALOG
		 L5 = 7
		 L2(L3, L4, L5)
	  elseif L1 == 7 then
		L0 = _util
		  L0 = L0.SetConversationCount
		  L1 = 10
		  L0(L1)
		  L0 = _util
		  L0 = L0.SetItemPopUpText
		  L1 = 31099
		  L2 = 34 --seaweed pizza
		  L0(L1, L2)
		  L0 = _util
		  L0 = L0.AddInventoryItem
		  L1 = 31099
		  L0(L1)
		  L0 = _util
		  L0 = L0.HideDialog
		  L0()
		  
		   L0 = _util
			L0 = L0.GetVar
			L1 = L0("HaveCreamSoda")
			L2 = L0("HaveRope")
			
			if L1 == 1 and L2 == 1 then
			L0 = _util
			L0 = L0.SetObjective
			L1 = 138	--return to captain rockhopper
			L0(L1)
			end
	  elseif L1 == 8 then
		  L2 = _util
		  L2 = L2.AddDialog
		  L3 = 152 	--squid pizza, coming right up
		  L4 = _const
		  L4 = L4.CHANGE_DIALOG
		  L5 = 9
		  L2(L3, L4, L5)
	  elseif L1 == 9 then
		L0 = _util
		  L0 = L0.SetConversationCount
		  L1 = 10
		  L0(L1)
		  L0 = _util
		  L0 = L0.SetItemPopUpText
		  L1 = 31084
		  L2 = 35 --squid pizza
		  L0(L1, L2)
		  L0 = _util
		  L0 = L0.AddInventoryItem
		  L1 = 31084
		  L0(L1)
		  L0 = _util
		  L0 = L0.HideDialog
		  L0()
		  
		    L0 = _util
			L0 = L0.GetVar
			L1 = L0("HaveCreamSoda")
			L2 = L0("HaveRope")
			
			if L1 == 1 and L2 == 1 then
			L0 = _util
			L0 = L0.SetObjective
			L1 = 138	--return to captain rockhopper
			L0(L1)
			end
	   else
		  L2 = _util
		  L2 = L2.AddDialog
		  L3 = 10	--I'll get cooking right away!
		  L4 = _const
		  L4 = L4.END_DIALOG
		  L5 = 10
		  L2(L3, L4, L5)
	   end
	end
end
