if _util.GetReason() == _const.CREATED then
  _util.AddInterest(_const.ITEM_DROPPED)
end
if _util.GetReason() == _const.ITEM_DROPPED and _util.GetConversationCount() == 5 then
  if _util.GetSource() == 55924 then
    _util.RemoveInventoryItem(55924)
    _util.SetVar("PizzaType", 0)
    _util.AddDialog(100, _const.CHANGE_DIALOG, 6)
  elseif _util.GetSource() == 31099 then
    _util.RemoveInventoryItem(31099)
    _util.SetVar("PizzaType", 1)
    _util.AddDialog(100, _const.CHANGE_DIALOG, 6)
  elseif _util.GetSource() == 31084 then
    _util.RemoveInventoryItem(31084)
    _util.SetVar("PizzaType", 2)
    _util.AddDialog(100, _const.CHANGE_DIALOG, 6)
  elseif _util.GetSource() == 39585 then
    _util.AddDialog(155, _const.END_DIALOG, 5)
  end
end
if _util.GetReason() == _const.TOUCHED then
  if _util.GetConversationCount() == 0 then
    _util.AddMonologue(153, "DownloadStrings")
  elseif _util.GetConversationCount() == 1 then
    _util.DelItem(30808)
    _util.AddDialog(87)
    _util.AddDialogButton(88, _const.CHANGE_NPC, 38132, 12)
  elseif _util.GetConversationCount() == 2 then
    _util.AddDialog(92, _const.CHANGE_DIALOG, 3)
  elseif _util.GetConversationCount() == 3 then
    _util.AddDialog(93, _const.CHANGE_DIALOG, 4)
  elseif _util.GetConversationCount() == 4 then
    _util.SetConversationCount(5)
    _util.AddDialog(94, _const.CHANGE_NPC, 38132, 14)
  elseif _util.GetConversationCount() == 5 then
    _util.AddDialog(154, _const.END_DIALOG, 5)
  elseif _util.GetConversationCount() == 6 then
    _util.AddDialog(101, _const.CHANGE_DIALOG, 7)
  elseif _util.GetConversationCount() == 7 then
    _util.AddDialog(102)
    _util.AddDialogButton(103, _const.CHANGE_DIALOG, _util.GetVar("PizzaType") + 8)
  elseif _util.GetConversationCount() == 8 then
    _util.SetConversationCount(11)
    _util.AddDialog(104, _const.CHANGE_NPC, 38132, 19)
  elseif _util.GetConversationCount() == 9 then
    _util.SetConversationCount(11)
    _util.AddDialog(105, _const.CHANGE_NPC, 38132, 19)
  elseif _util.GetConversationCount() == 10 then
    _util.SetConversationCount(11)
    _util.AddDialog(106, _const.CHANGE_NPC, 38132, 19)
  elseif _util.GetConversationCount() == 11 then
    _util.AddMonologue(107, "DownloadStrings")
  end
end
