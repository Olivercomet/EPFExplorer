local L0, L1, L2, L3, L4, L5

L1 = _util
L1 = L1.GetReason
L1 = L1()
L2 = _const
L2 = L2.CREATED
if L1 == L2 then
  L1 = _util
  L1 = L1.AddInterest
  L2 = _const
  L2 = L2.ITEM_DROPPED
  L1(L2)
end

L1 = _util
L1 = L1.GetReason
L1 = L1()
L2 = _const
L2 = L2.ITEM_DROPPED
if L1 == L2 then
  L1 = _util
  L1 = L1.GetSource
  L1 = L1()
  L5 = _util
  L5 = L5.GetConversationCount
  L5 = L5()
  
  if L5 == 5 then	
	L4 = _util
	L4 = L4.RemoveInventoryItem
	L5 = _util
	L5 = L5.SetVar
    if L1 == 55924 then   --hot sauce pizza
		L4(55924)
		L5("PizzaType",0)
		L2 = _util
		L2 = L2.AddDialog
		L3 = 100 --What’s this? Oh!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 6
		L2(L3, L4, L5)
	elseif L1 == 31099 then   --seaweed pizza
		L4(31099)
		L5("PizzaType",1)
		L2 = _util
		L2 = L2.AddDialog
		L3 = 100 --What’s this? Oh!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 6
		L2(L3, L4, L5)
	elseif L1 == 31084 then   --squid pizza
		L4(31084)
		L5("PizzaType",2)
		L2 = _util
		L2 = L2.AddDialog
		L3 = 100 --What’s this? Oh!
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 6
		L2(L3, L4, L5)
    elseif L1 == 39585 then	--if you try to give him the thermos
		L2 = _util
		L2 = L2.AddDialog
		L3 = 155 --Thanks for the offer, Agent, but I'm more of a tea person.
		L4 = _const
		L4 = L4.END_DIALOG
		L5 = 5
		L2(L3, L4, L5)
	end
  end
end

L1 = _util
L1 = L1.GetReason
L1 = L1()
L2 = _const
L2 = L2.TOUCHED

	if L1 == L2 then
	  L1 = _util
	  L1 = L1.GetConversationCount
	  L1 = L1()
	  if L1 == 0 then
		L1 = _util
		L1 = L1.AddMonologue
		L2 = 153
		L3 = "DownloadStrings"
		L1(L2, L3)
	  elseif L1 == 1 then
	    L0 = _util
		L0 = L0.DelItem
		L0(30808)
		L2 = _util
		L2 = L2.AddDialog
		L3 = 87 --Ahhhh!!!
		L2(L3)
		L2 = _util
		L2 = L2.AddDialogButton
		L3 = 88 --Herbert! Where are you?
		L4 = _const
		L4 = L4.CHANGE_NPC
		L5 = 38132 --change to rockhopper
		L0 = 12
		L2(L3, L4, L5, L0)
	  elseif L1 == 2 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 92 	--Don't worry, I've landed on something
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 3
		L2(L3, L4, L5)
	  elseif L1 == 3 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 93 --Wait... is this another...
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 4
		L2(L3, L4, L5)
	  elseif L1 == 4 then
	    L2 = _util
		L2 = L2.SetConversationCount
		L2(5)
		L2 = _util
		L2 = L2.AddDialog
		L3 = 94 	--...ICEBERG? NOOOOOOOOOOOOOO!
		L4 = _const
		L4 = L4.CHANGE_NPC	--change to rockhopper NPC
		L5 = 38132
		L0 = 14
		L2(L3, L4, L5, L0)
	elseif L1 == 5 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 154 --Argghh... why me...?
		L4 = _const
		L4 = L4.END_DIALOG
		L5 = 5
		L2(L3, L4, L5)
	elseif L1 == 6 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 101 --Agent… I begrudgingly give you my thanks.
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = 7
		L2(L3, L4, L5)
	elseif L1 == 7 then
		L2 = _util
		L2 = L2.AddDialog
		L3 = 102 --I never thought I’d say this, but may we meet again. I now remember just how tedious it was to be lost at sea.
		L2(L3)
		L2 = _util
		L2 = L2.AddDialogButton
		L3 = 103 --You’re welcome, Herbert.
		L4 = _const
		L4 = L4.CHANGE_DIALOG
		L5 = _util
		L5 = _util.GetVar
		L5 = L5("PizzaType")
		L5 = L5 + 8
		L2(L3, L4, L5)
	elseif L1 == 8 then
		L2 = _util
		L2 = L2.SetConversationCount
		L2(11)
		L2 = _util
		L2 = L2.AddDialog
		L3 = 104 --OWCHHH!! Hot, hot hot!!! What are you playing at, Agent!?
		L4 = _const
		L4 = L4.CHANGE_NPC
		L5 = 38132
		L0 = 19
		L2(L3, L4, L5, L0)
	elseif L1 == 9 then
		L2 = _util
		L2 = L2.SetConversationCount
		L2(11)
		L2 = _util
		L2 = L2.AddDialog
		L3 = 105 --Thank goodness it’s vegetarian!!!
		L4 = _const
		L4 = L4.CHANGE_NPC
		L5 = 38132
		L0 = 19
		L2(L3, L4, L5, L0)
	elseif L1 == 10 then
		L2 = _util
		L2 = L2.SetConversationCount
		L2(11)
		L2 = _util
		L2 = L2.AddDialog
		L3 = 106 --Squid Pizza?! I’ll have my revenge, Agent. Mark my words...
		L4 = _const
		L4 = L4.CHANGE_NPC
		L5 = 38132
		L0 = 19
		L2(L3, L4, L5, L0)
	elseif L1 == 11 then
		L1 = _util
		L1 = L1.AddMonologue
		L2 = 107
		L3 = "DownloadStrings"
		L1(L2, L3)
	   end
	end
