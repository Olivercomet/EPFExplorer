local L0, L1, L2, L3, L4, L5
L4 = _util
L4 = L4.GetReason
L4 = L4()
L5 = _const
L5 = L5.TOUCHED

L0 = _util
L0 = L0.GetConversationCount
L0 = L0()

if L4 == L5 then
  if L0 == 0 then
	L1 = _util
	L1 = L1.AddConversation
	L2 = 123	--Good to see you safe, Agent. And good thinking with that cream soda!
	L3 = 124  --Thanks G. But we lost Herbert...
	L4 = -1
	L5 = _const
	L5 = L5.CHANGE_DIALOG
	L0 = 1
	L1(L2, L3, L4, L5, L0)
  elseif L0 == 1 then
	L1 = _util
	L1 = L1.AddDialog
	L2 = 125 	--Don't worry, [playername]. The currents will take him back to Club Penguin after a few days.
	L3 = _const
	L3 = L3.CHANGE_DIALOG
	L4 = 2
	L1(L2, L3, L4)
  elseif L0 == 2 then
	L2 = _util
	L2 = L2.AddDialog
	L3 = 126 -- Although, we could get him right now with the Hydro Hopper, come to think of it...
	L2(L3)
	L2 = _util
	L2 = L2.AddDialogButton
	L3 = 127 --Good idea, let's do that.
	L4 = _const
	L4 = L4.CHANGE_DIALOG
	L5 = 3
	L2(L3, L4, L5)
	L2 = _util
	L2 = L2.AddDialogButton
	L3 = 129 --No, he needs to learn his lesson.
	L4 = _const
	L4 = L4.CHANGE_DIALOG
	L5 = 4
	L2(L3, L4, L5)
  elseif L0 == 3 then
	L1 = _util
	L1 = L1.AddDialog
	L2 = 128 	--Right! I'll ask the owner to take the boat out right away.
	L3 = _const
	L3 = L3.CHANGE_DIALOG
	L4 = 5
	L1(L2, L3, L4)
  elseif L0 == 4 then
	L1 = _util
	L1 = L1.AddDialog
	L2 = 130 	--Hmm, you might be right there. Maybe next time he'll think twice before he plans another double-cross.
	L3 = _const
	L3 = L3.CHANGE_DIALOG
	L4 = 5
	L1(L2, L3, L4)
  elseif L0 == 5 then
	L0 = _util
    L0 = L0.AddDialog
    L1 = 131  --Thanks for your help, Agent. I'm sure we'll meet again soon.
    L2 = _const
    L2 = L2.END_MISSION
    L0(L1, L2)
  end
end