if _util.GetReason() == _const.TOUCHED then
  if _util.GetConversationCount() == 0 then
    _util.AddConversation(123, 124, -1, _const.CHANGE_DIALOG, 1)
  elseif _util.GetConversationCount() == 1 then
    _util.AddDialog(125, _const.CHANGE_DIALOG, 2)
  elseif _util.GetConversationCount() == 2 then
    _util.AddDialog(126)
    _util.AddDialogButton(127, _const.CHANGE_DIALOG, 3)
    _util.AddDialogButton(129, _const.CHANGE_DIALOG, 4)
  elseif _util.GetConversationCount() == 3 then
    _util.AddDialog(128, _const.CHANGE_DIALOG, 5)
  elseif _util.GetConversationCount() == 4 then
    _util.AddDialog(130, _const.CHANGE_DIALOG, 5)
  elseif _util.GetConversationCount() == 5 then
    _util.AddDialog(131, _const.END_MISSION)
  end
end
