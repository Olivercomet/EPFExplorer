local L0, L1, L2

L0 = _util
L0 = L0.SetCursorPos
L1 = 424
L2 = 166
L0(L1,L2,L2)

L0 = _util
L0 = L0.GetVar
L0 = L0("LookForSupplies")

if L0 == 1 then
	L0 = _util
	L0 = L0.ActivateNpc
	L0(38132,0)
	L0 = _util
	L0 = L0.SetVar
	L1 = "LookForSupplies"
	L2 = 0
	L0(L1,L2)
end