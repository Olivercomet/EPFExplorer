_util.SetCursorPos(424, 166, 166)
if _util.GetVar("LookForSupplies") == 1 then
  _util.ActivateNpc(38132, 0)
  _util.SetVar("LookForSupplies", 0)
end
